package com.barclayscard.customerquery.event;

import com.barclayscard.customerquery.domain.Address;

public class AddressUpdatedEvent extends AbstractEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Address address;

	public AddressUpdatedEvent(String id, Address address) {
		super(id);
		this.address = address;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

}
