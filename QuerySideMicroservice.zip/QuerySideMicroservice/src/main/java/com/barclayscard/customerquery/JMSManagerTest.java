package com.barclayscard.customerquery;

import static org.junit.Assert.*;
 
import org.junit.Before;
import org.junit.Test;

import com.barclayscard.customerquery.configuration.QueueListener;
 
public class JMSManagerTest
{
    private JMSManager jmsManager;
    private QueueListener listener;
 
    @Before
    public void setup()
    {
        jmsManager = new JMSManager();
        listener = new QueueListener();
    }
 
    @Test
    public void testSendSimpleObject()
    {
        try
        {
        	EventMessage eventMessage = new EventMessage(1,
        			"Message from FirstClient");
        	jmsManager.sendMessage(eventMessage, "myQ");
        }
        catch (Exception e)
        {
            fail(e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
    public void read()
    {
        try
        {
        	
        	listener.onMessage(null);
        }
        catch (Exception e)
        {
            fail(e.getMessage());
            e.printStackTrace();
        }
    }
 
}