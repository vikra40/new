package com.barclayscardcustomerquery;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.barclayscard.customerquery.domain.Address;
import com.barclayscard.customerquery.event.AbstractEvent;
import com.barclayscard.customerquery.event.CustomerAddedEvent;
import com.barclayscard.customerquery.handler.CustomerViewEventHandler;
import com.barclayscard.customerquery.repository.CustomerRepository;

@RunWith(SpringRunner.class)

@SpringBootTest
public class BarclaysCardCustomerQueryMicroserviceApplicationTests {

	/*
	 * @Test public void contextLoads() { }
	 */

	@Autowired
	 CustomerRepository customerRepository;


	@Before
	public void setUp() throws Exception {

			/*Iterable<Customer> all = customerRepository.findAll();
		Customer orderBookEntry = all.iterator().next();
	*///	assertNotNull("The first item of the iterator for orderbooks should not be null", orderBookEntry);
	//	assertEquals("Test Company", orderBookEntry.getFirstName());

	}

	@Test
	public void testAddedEvent() throws Exception {
		AbstractEvent id;
		Date dd = new Date();
		Address address = new Address("ss", "ddd", "223");
		CustomerAddedEvent event = new CustomerAddedEvent("5", "abc", "ww", "sdsd", "dsd", address, dd);

		CustomerViewEventHandler listener = new CustomerViewEventHandler();
		listener.setCustomerRepository(customerRepository);
		listener.handle(event);

	}

}
