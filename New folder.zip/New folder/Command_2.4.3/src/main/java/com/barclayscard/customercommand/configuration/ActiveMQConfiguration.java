package com.barclayscard.customercommand.configuration;


import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.stereotype.Component;


@Component
public class ActiveMQConfiguration {

	private MessageProducer producer;

	private Session session;

	public ActiveMQConfiguration() throws JMSException {

		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("failover:tcp://localhost:61616");

		Connection connection = connectionFactory.createConnection();
		connection.start();

		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

		Destination destination = session.createQueue("sTest");

		producer = session.createProducer(destination);
		producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
	}

	/**
	 * This method will be automatically invoked when an event for Customer
	 * Added will be received. The method will simple write the received event
	 * in the ActiveMQ as JSON string
	 * 
	 * @author apatel5
	 * @param CustomerAddedEvent
	 *            the event object that will be handled in the method
	 * @throws JMSException
	 */
	/*@EventHandler
	public void handle(CustomerAddedEvent event) throws JMSException {

		System.out.println("Got event in handler");

		TextMessage message = session.createTextMessage(JSONUtil.convertObjectToJSON(event));

		producer.send(message);

	}*/

}