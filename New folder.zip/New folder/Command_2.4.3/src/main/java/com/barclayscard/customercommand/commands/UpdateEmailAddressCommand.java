package com.barclayscard.customercommand.commands;

import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Command for Update EmailAddress
 *
 */
public class UpdateEmailAddressCommand {

	@TargetAggregateIdentifier
	private final String id;
	
	
	@NotNull(message = "Email Address is mandatory")
	@NotBlank
	private final String emailAddress;

	public UpdateEmailAddressCommand(String id, String emailAddress) {
		super();
		this.id = id;
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

}
