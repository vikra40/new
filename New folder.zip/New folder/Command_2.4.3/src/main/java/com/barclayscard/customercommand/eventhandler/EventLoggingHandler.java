package com.barclayscard.customercommand.eventhandler;


import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.axonframework.eventhandling.annotation.EventHandler;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Component;

import com.barclayscard.customercommand.aggregates.CustomerAggregate;
import com.barclayscard.customercommand.events.CustomerAddedEvent;
import com.barclayscard.customercommand.util.JsonConvertor;

/**
 * EventHandler's ( EventListeners) are used to react to events and perform associated
 * actions.
 * This event handler is used to update the repository data of the query side in the CQRS
 */

@Component
public class EventLoggingHandler {

	private MessageProducer producer;

	@Autowired
	private JmsMessagingTemplate jmsMessagingTemplate;
	private Session session;
	@Autowired
	  private EventSourcingRepository<CustomerAggregate> repo;
	
	public EventLoggingHandler() throws JMSException {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("failover:tcp://localhost:61616");
		Connection connection = connectionFactory.createConnection();
		connection.start();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination destination = session.createQueue("activemq");
		
		producer = session.createProducer(destination);
		producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
	}
	

	/*@Autowired
	public EventLoggingHandler(JmsMessagingTemplate  jmsMessagingTemplate, EventSourcingRepository<CustomerAggregate> repo) throws JMSException {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("failover:tcp://localhost:61616");
		Connection connection = connectionFactory.createConnection();
		connection.start();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination destination = session.createQueue("activemq");
		
		producer = session.createProducer(destination);
		producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
		this.jmsMessagingTemplate = jmsMessagingTemplate;
		this.repo = repo;
	}*/
	
    private static final Logger LOG = LoggerFactory.getLogger(EventLoggingHandler.class);
    private static final String IID = String.valueOf(Double.valueOf(Math.random() * 1000).intValue());

    
    
   /* @EventHandler
	void on(CustomerAddedEvent event) throws MessagingException, JMSException {
		publish(event.getFirstName(), event);
	}
    
    
    private void publish(String username, CustomerEvent event) throws MessagingException, JMSException {
		String type = event.getClass().getSimpleName();
		this.jmsMessagingTemplate.convertAndSend("activemq", new CustomerEventNotification(type,event));
	}
    */
    
    @EventHandler
    public void handle(CustomerAddedEvent event) {
        LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getFirstName(),event.getLastName(),event.getMobileNumber(),event.getEmailAddress(),event.getAddress(),event.getDob());
        System.out.println("Got event in handler");

		/*TextMessage message;
		try {
			message = session.createTextMessage(JsonConvertor.convertObjectToJSON(event));
			producer.send(message);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/
		jmsMessagingTemplate.convertAndSend("activemq", event);
		
    }
    
    
   /* @EventHandler
    public void handle(MobileNumberUpdatedEvent event) {
        LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getMobileNumber());
        TextMessage message;
		try {
			message = session.createTextMessage(JsonConvertor.convertObjectToJSON(event));
			producer.send(message);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @EventHandler
    public void handle(DobUpdatedEvent event) {
    	LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getDob());
    	TextMessage message;
		try {
			message = session.createTextMessage(JsonConvertor.convertObjectToJSON(event));
			producer.send(message);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @EventHandler
    public void handle(AddressUpdatedEvent event) {

    	LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getAddress());
    	TextMessage message;
		try {
			message = session.createTextMessage(JsonConvertor.convertObjectToJSON(event));
			producer.send(message);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @EventHandler
    public void handle(EmailAddressUpdatedEvent event) {

    	LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getEmailAddress());
    	TextMessage message;
		try {
			message = session.createTextMessage(JsonConvertor.convertObjectToJSON(event));
			producer.send(message);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }*/
}
