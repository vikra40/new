package com.barclayscard.customercommand.commands;

import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

/**
 *  Command for Update Mobile Number.
 *
 */
public class UpdateMobileNumberCommand {

	@TargetAggregateIdentifier
	private String id;
	
	@NotNull(message = "Mobile Number is mandatory")
	@NotBlank
	private String mobileNumber;

	public UpdateMobileNumberCommand(){
		
	}
	public UpdateMobileNumberCommand(String id, String mobileNumber) {
		super();
		this.id = id;
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

}
