package com.barclayscard.customercommand.events;

/**
 * This is the event class for updation of email address of customer
 */
public class EmailAddressUpdatedEvent extends AbstractEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String emailAddress;

	public EmailAddressUpdatedEvent(String id, String emailAddress) {
		super(id);
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return the emailaddress
	 */
	
}
