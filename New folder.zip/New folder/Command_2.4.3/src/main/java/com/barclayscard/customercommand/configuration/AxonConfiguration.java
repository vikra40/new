package com.barclayscard.customercommand.configuration;

import java.util.ArrayList;
import java.util.List;

import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.commandhandling.annotation.AggregateAnnotationCommandHandler;
import org.axonframework.commandhandling.annotation.AnnotationCommandHandlerBeanPostProcessor;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.commandhandling.gateway.CommandGatewayFactoryBean;
import org.axonframework.contextsupport.spring.AnnotationDriven;
import org.axonframework.domain.DomainEventStream;
import org.axonframework.eventhandling.ClusteringEventBus;
import org.axonframework.eventhandling.DefaultClusterSelector;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventstore.EventStore;
import org.axonframework.eventstore.management.EventStoreManagement;
import org.axonframework.eventstore.mongo.DefaultMongoTemplate;
import org.axonframework.eventstore.mongo.MongoEventStore;
import org.axonframework.eventstore.mongo.MongoTemplate;
import org.axonframework.serializer.json.JacksonSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.barclayscard.customercommand.aggregates.CustomerAggregate;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
/**
 * Axon Configuration
 *
 */
@Configuration
@AnnotationDriven
public class AxonConfiguration {


    @Autowired
    public Mongo mongo;


	@Value("${mongodb.dbname}")
	private String mongoDbName;

	@Value("${mongodb.events.collection.name}")
	private String eventsCollectionName;

	@Value("${mongodb.events.snapshot.collection.name}")
	private String snapshotCollectionName;



    @Bean
    JacksonSerializer axonJsonSerializer() {
        return new JacksonSerializer();
    }


    @Bean
    EventBus eventBus() {
        return new ClusteringEventBus(new DefaultClusterSelector());
    }

    @Bean(name = "axonMongoTemplate")
    MongoTemplate axonMongoTemplate() {
        MongoTemplate template = new DefaultMongoTemplate(mongo,
        		mongoDbName, eventsCollectionName, snapshotCollectionName, null, null);
        return template;
    }
    
    
 

    @Bean
    EventStore eventStore() {
        MongoEventStore eventStore = new MongoEventStore(axonJsonSerializer(), axonMongoTemplate());    
        return eventStore;
    }

    @Bean
    EventSourcingRepository<CustomerAggregate> customerEventSourcingRepository() {
        EventSourcingRepository<CustomerAggregate> repo = new EventSourcingRepository<CustomerAggregate>(CustomerAggregate.class, eventStore());
        repo.setEventBus(eventBus());
        return repo;
    }

    @Bean
    CommandBus commandBus() {
        SimpleCommandBus commandBus = new SimpleCommandBus();
        return commandBus;
    }

    @Bean
    CommandGatewayFactoryBean<CommandGateway> commandGatewayFactoryBean() {
        CommandGatewayFactoryBean<CommandGateway> factory = new CommandGatewayFactoryBean<CommandGateway>();
        factory.setCommandBus(commandBus());
        return factory;
    }

   
    /**
     * This method allows Axon to automatically find your @CommandHandler's
     *
     * @return
     */
    @Bean
    AnnotationCommandHandlerBeanPostProcessor commandHandlerBeanPostProcessor() {
        AnnotationCommandHandlerBeanPostProcessor proc = new AnnotationCommandHandlerBeanPostProcessor();
        proc.setCommandBus(commandBus());
        return proc;
    }

    /**
     * This method registers your Aggregate Root as a @CommandHandler
     *
     * @return
     */
    @Bean
    AggregateAnnotationCommandHandler<CustomerAggregate> customerAggregateCommandHandler() {
        AggregateAnnotationCommandHandler<CustomerAggregate> handler = new AggregateAnnotationCommandHandler<CustomerAggregate>(
        		CustomerAggregate.class,
                customerEventSourcingRepository(),
                commandBus());
        return handler;
    }

	

}
