package com.barclayscard.customercommand.aggregates;


import java.util.Date;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.domain.DomainEventMessage;
import org.axonframework.eventsourcing.AbstractEventSourcedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;
import com.barclayscard.customercommand.commands.AddCustomerCommand;
import com.barclayscard.customercommand.commands.UpdateAddressCommand;
import com.barclayscard.customercommand.commands.UpdateEmailAddressCommand;
import com.barclayscard.customercommand.commands.UpdateMobileNumberCommand;
import com.barclayscard.customercommand.events.AddressUpdatedEvent;
import com.barclayscard.customercommand.events.CustomerAddedEvent;
import com.barclayscard.customercommand.events.EmailAddressUpdatedEvent;
import com.barclayscard.customercommand.events.MobileNumberUpdatedEvent;
import com.barclayscard.customercommand.util.CustomerMapper;
import com.barclayscard.customercommand.valueobjects.Address;
/**
 * CustomerAggregate is essentially a DDD AggregateRoot (from the DDD concept). In event-sourced
 * systems, Aggregates are often stored and retreived using a 'Repository'. In the
 * simplest terms, Aggregates are the sum of their applied 'Events'.
 * <p/>
 * The Repository stores the aggregate's Events in an 'Event Store'. When an Aggregate
 * is re-loaded by the repository, the Repository re-applies all the stored events
 * to the aggregate thereby re-creating the logical state of the Aggregate.
 * <p/>
 * The CustomerAggregate Aggregate can handle and react to 'Commands', and when it reacts
 * to these com.barclayscard.customercommand.commands it creates and 'applies' Events that represent the logical changes
 * to be made. These Events are also handled by the CustomerAggregate.
 * <p/>
 * Axon takes care of much of this via the CommandBus, EventBus and Repository.
 * <p/>
 * Axon delivers com.barclayscard.customercommand.commands placed on the bus to the Aggregate. Axon supports the 'applying' of
 * Events to the Aggregate, and the handling of those events by the aggregate or any other
 * configured EventHandlers.
 * @param <I>
 */

public class CustomerAggregate<I> extends AbstractAnnotatedAggregateRoot<I>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(CustomerAggregate.class);

	@Autowired
	RestTemplate restTemplate;

	@Value("${REST.URL}")
	private String BASE_URL;
	
	
	 /**
     * Aggregates that are managed by Axon must have a unique identifier.
     * Strategies similar to GUID are often used. The annotation 'AggregateIdentifier'
     * identifies the id field as such.
     */

	@AggregateIdentifier
	private String id;

	private String firstName;

	private String lastName;

	private String mobileNumber;

	private String emailAddress;

	private Address address;

	private Date dob;

	
	   /**
     * This default constructor is used by the Repository to construct
     * a prototype CustomerAggregate. Events are then used to set properties
     * such as the CustomerAggregate's Id in order to make the Aggregate reflect
     * it's true logical state.
     */
	public CustomerAggregate() {

	}

	
	
	  /**
     * This constructor is marked as a 'CommandHandler' for the
     * AddCustomerCommand. This command can be used to construct
     * new instances of the Aggregate. If successful a new CustomerAddedEvent
     * is 'applied' to the aggregate using the Axon 'apply' method. The apply
     * method appears to also propagate the Event to any other registered
     * 'Event Listeners', who may take further action.
     *
     * @param command
     */
	@CommandHandler
	public CustomerAggregate(AddCustomerCommand command) {
		LOG.info("Command: 'AddCustomerCommand' received.");
		LOG.info("Queuing up a new CustomerAddedEvent for Customerid '{}'", command.getId());
		apply(new CustomerAddedEvent(command.getId(), command.getFirstName(), command.getLastName(),
				command.getMobileNumber(), command.getEmailAddress(), command.getAddress(), command.getDob()));
	}
	

	@CommandHandler
	public  CustomerAggregate(UpdateMobileNumberCommand command) {
		System.out.println("====IN UPDATEMOB NO====");
		LOG.debug("Command: 'UpdateMobileNumberCommand' received.");
		LOG.debug("Queuing up a new UpdateMobileNumberCommand for CustomerId '{}'", command.getId());
		apply(new MobileNumberUpdatedEvent(command.getId(), command.getMobileNumber()));
	}

/*
	@CommandHandler
	public void handle(UpdateMobileNumberCommand command) {
		LOG.debug("Command: 'UpdateMobileNumberCommand' received.");
		LOG.debug("Queuing up a new UpdateMobileNumberCommand for CustomerId '{}'", command.getId());
		CustomerMapper customer = restTemplate.getForObject(BASE_URL + command.getId(), CustomerMapper.class, HttpStatus.OK);
		if ((customer.getId().equals(command.getId()))
				&& !(command.getMobileNumber().equals(customer.getMobileNumber()))) {
			apply(new MobileNumberUpdatedEvent(command.getId(), command.getMobileNumber()));
		} else {
			LOG.debug("Customer data already present in Query Database for MobileNumber '{}'",
					command.getMobileNumber());
		}
	}
*/
	@CommandHandler
	public void handle(UpdateEmailAddressCommand command) {
		LOG.debug("Command: 'AddCustomerCommand' received.");
		LOG.debug("Queuing up a new EmailUpdatedAddressEvent for CustomerId '{}'", command.getId());
		CustomerMapper customer = restTemplate.getForObject(BASE_URL + command.getId(), CustomerMapper.class, HttpStatus.OK);
		if ((customer.getId().equals(command.getId()))
				&& !(command.getEmailAddress().equals(customer.getEmailAddress()))) {
			apply(new EmailAddressUpdatedEvent(command.getId(), command.getEmailAddress()));
		} else {
			LOG.debug("Customer data already present in Query Database for EmailAddress '{}'",
					command.getEmailAddress());
		}
	}

	@CommandHandler
	public void handle(UpdateAddressCommand command) {
		LOG.debug("Command: 'AddCustomerCommand' received.");
		LOG.debug("Queuing up a new AddressUpdatedEvent for CustomerId '{}'", command.getId());
		CustomerMapper customer = restTemplate.getForObject(BASE_URL + command.getId(), CustomerMapper.class, HttpStatus.OK);
		if ((customer.getId().equals(command.getId())) && !(command.getAddress().equals(customer.getAddress()))) {
			apply(new AddressUpdatedEvent(command.getId(), command.getAddress()));
		} else {
			LOG.debug("Customer data already present in Query Database for Address '{}'", command.getAddress());
		}
	}
	
	 /**
     * This method is marked as an EventSourcingHandler and is therefore used by the Axon framework to
     * handle events of the specified type (CustomerAddedEvent). The CustomerAddedEvent can be
     * raised either by the constructor during CustomerAggregate(AddCustomerCommand) or by the
     * Repository when 're-loading' the aggregate.
     *
     * @param event
     */

	@EventSourcingHandler
	public void on(CustomerAddedEvent event) {
		this.id = event.getId();
		this.firstName = event.getFirstName();
		this.emailAddress = event.getEmailAddress();
		this.dob = event.getDob();
		this.mobileNumber = event.getMobileNumber();
		this.address = event.getAddress();
		LOG.info("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(), event.getFirstName(), event.getLastName(),
				event.getMobileNumber(), event.getEmailAddress(), event.getDob());
	}

	@EventSourcingHandler
	public void on(MobileNumberUpdatedEvent event) {
		this.id = event.getId();
		this.mobileNumber = event.getMobileNumber();
		LOG.debug("Applied: 'MobileNumberUpdatedEvent' [{}] '{}'", event.getId(), event.getMobileNumber());
	}

	@EventSourcingHandler
	public void on(AddressUpdatedEvent event) {
		this.id = event.getId();
		this.address = event.getAddress();
		LOG.debug("Applied: 'AddressUpdatedEvent' [{}] '{}'", event.getId(), event.getAddress());
	}

	@EventSourcingHandler
	public void on(EmailAddressUpdatedEvent event) {
		this.id = event.getId();
		this.emailAddress = event.getEmailAddress();
		LOG.debug("Applied: 'EmailUpdatedAddressEvent' [{}] '{}'", event.getId(), event.getEmailAddress());
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}


}
