package com.barclayscard.customercommand.commands;

import java.util.Date;
import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;
import com.barclayscard.customercommand.valueobjects.Address;

/**
 * Command for add customer
 *
 */
public class AddCustomerCommand {

	@TargetAggregateIdentifier
	private final String id;

	@NotNull(message = "First Name is mandatory")
	@NotBlank
	private final String firstName;

	
	@NotNull(message = "Last Name is mandatory")
	@NotBlank
	private final String lastName;

	
	@NotNull(message = "MobileNumber is mandatory")
	@NotBlank
	private final String mobileNumber;

	
	@NotNull(message = "EmailAddress is mandatory")
	@NotBlank
	private final String emailAddress;

	
	@NotNull
	private final Address address;

	@NotNull(message = "DOB is mandatory")
	private final Date dob;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	
	public AddCustomerCommand(String id, String firstName, String lastName, String mobileNumber, String emailAddress,
			Address address, Date dob) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailAddress = emailAddress;
		this.address = address;
		this.dob = dob;
	}

}
