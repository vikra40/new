package com.barclayscard.customercommand.commands;

import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

import com.barclayscard.customercommand.valueobjects.Address;

/**
 * Command for Update Address
 *
 */
public class UpdateAddressCommand {

	@TargetAggregateIdentifier
	private final String id;
	
	@NotNull
	private final Address address;

	public UpdateAddressCommand(String id, Address address) {
		super();
		this.id = id;
		this.address = address;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

}
