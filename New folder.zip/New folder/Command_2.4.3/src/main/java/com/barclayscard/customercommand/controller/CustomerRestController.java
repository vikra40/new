package com.barclayscard.customercommand.controller;

import javax.servlet.http.HttpServletResponse;

import org.axonframework.commandhandling.CommandExecutionException;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.domain.DefaultIdentifierFactory;
import org.axonframework.domain.IdentifierFactory;
import org.axonframework.repository.ConcurrencyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.barclayscard.customercommand.commands.AddCustomerCommand;
import com.barclayscard.customercommand.commands.UpdateAddressCommand;
import com.barclayscard.customercommand.commands.UpdateEmailAddressCommand;
import com.barclayscard.customercommand.commands.UpdateMobileNumberCommand;
import com.barclayscard.customercommand.entity.Customer;

/**
 * This is rest controller class for handling all the customer requests
 *
 */
@RestController
@RequestMapping("/customers")
public class CustomerRestController {

	private static final Logger LOG = LoggerFactory.getLogger(CustomerRestController.class);
	private final IdentifierFactory identifierFactory = new DefaultIdentifierFactory();

	@Autowired
	CommandGateway commandGateway;

	/**
	 * This REST Api is use for accepting request for customer creation
	 */
	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	public void add(@RequestBody Customer customer, HttpServletResponse response) {
		LOG.debug("Adding customer [{}] '{}'", identifierFactory.generateIdentifier(), customer.getFirstName(),
				customer.getLastName(), customer.getMobileNumber(), customer.getEmailAddress(), customer.getDob());

		try {
			AddCustomerCommand command = new AddCustomerCommand(identifierFactory.generateIdentifier(),
					customer.getFirstName(), customer.getLastName(), customer.getMobileNumber(),
					customer.getEmailAddress(), customer.getAddress(), customer.getDob());
			try {
				commandGateway.send(command);
			} catch (Exception e) {
				
			}
			LOG.info("Added Customer [{}] '{}'", identifierFactory.generateIdentifier(), customer.getFirstName(),
					customer.getLastName(), customer.getMobileNumber(), customer.getEmailAddress(),
					customer.getDob());
			response.setStatus(HttpServletResponse.SC_CREATED);
			return;
		} catch (AssertionError ae) {
			LOG.warn("Add Request failed - empty params?. [{}] '{}'", identifierFactory.generateIdentifier(),
					customer.getFirstName(), customer.getLastName(), customer.getMobileNumber(),
					customer.getEmailAddress(), customer.getDob());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (CommandExecutionException cex) {
			LOG.warn("Add Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);

			if (null != cex.getCause()) {
				LOG.warn("Caused by: {} {}", cex.getCause().getClass().getName(), cex.getCause().getMessage());
				if (cex.getCause() instanceof ConcurrencyException) {
					LOG.warn("A duplicate customer with the same ID [{}] already exists.",
							identifierFactory.generateIdentifier());
					response.setStatus(HttpServletResponse.SC_CONFLICT);
				}
			}
		}
	}

	/**
	 * This REST Api is use for accepting request for customer Address update 
	 */
	@RequestMapping(value = "updatecustomer/address/{id}", method = RequestMethod.PUT)
	public void updateAddress(@RequestBody com.barclayscard.customercommand.valueobjects.Address address,
			@PathVariable String id, HttpServletResponse response) {
		UpdateAddressCommand updateaddresscommand = new UpdateAddressCommand(id, address);
		try {
			try {
				commandGateway.send(updateaddresscommand);
			} catch (Exception e) {
		
			}
			LOG.info("Updated Customer Address ", updateaddresscommand.getId(),
					updateaddresscommand.getAddress().toString());
			response.setStatus(HttpServletResponse.SC_OK);
			return;
		} catch (AssertionError ae) {
			LOG.warn("Update Customer Address Request failed - empty params?. [{}] '{}'", updateaddresscommand.getId(),
					updateaddresscommand.getAddress().toString());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (CommandExecutionException cex) {
			LOG.warn("Update Customer LastName Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

	/**
	 * This REST Api is use for accepting request for customer Email address update 
	 */
	@RequestMapping(value = "updatecustomer/emailaddress/{id}", method = RequestMethod.PUT)
	public void updateEmailAddress(@RequestParam("emailAddress") String emailaddress, @PathVariable String id,
			HttpServletResponse response) {
		UpdateEmailAddressCommand updateemailaddresscommand = new UpdateEmailAddressCommand(id, emailaddress);

		try {
			try {
				commandGateway.send(updateemailaddresscommand);
			} catch (Exception e) {
			}
			LOG.info("Updated Customer EmailAddress ", updateemailaddresscommand.getId(),
					updateemailaddresscommand.getEmailAddress());
			response.setStatus(HttpServletResponse.SC_OK);
			return;
		} catch (AssertionError ae) {
			LOG.warn("Update Customer EmailAddress Request failed - empty params?. [{}] '{}'",
					updateemailaddresscommand.getId(), updateemailaddresscommand.getEmailAddress());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (CommandExecutionException cex) {
			LOG.warn("Update Customer EmailAddress Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

	/**
	 * This REST Api is use for accepting request for customer mobile number update 
	 */
	@RequestMapping(value = "/updatecustomermobilenumber/{id}", method = RequestMethod.POST)
	public void updateMobileNumber(@RequestParam("mobileNumber") String mobileNumber, @PathVariable String id,
			HttpServletResponse response) {
		
		System.out.println("=======IN UPDATE MOBILENO====");
		UpdateMobileNumberCommand updatemobilecommand = new UpdateMobileNumberCommand(id, mobileNumber);
		try {
			try {
				commandGateway.send(updatemobilecommand);
			} catch (Exception e) {
				
			}
			LOG.info("Updated Customer MobileNo ", updatemobilecommand.getId(), updatemobilecommand.getMobileNumber());
			response.setStatus(HttpServletResponse.SC_OK);
			return;
		} catch (AssertionError ae) {
			LOG.warn("Update Customer MobileNo Request failed - empty params?. [{}] '{}'", updatemobilecommand.getId(),
					updatemobilecommand.getMobileNumber());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (CommandExecutionException cex) {
			LOG.warn("Update Customer MobileNo Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

}
