package com.barclayscard.customercommand.valueobjects;

import java.io.Serializable;

/**
 * This class treated as an value object for customer aggregate root
 *
 */
public class Address implements Serializable {

	private String buildingName;

	private String streetName;

	private String pincode;
	
	public Address(){
		
	}

	public Address(String buildingName, String streetName, String pincode) {
		super();
		this.buildingName = buildingName;
		this.streetName = streetName;
		this.pincode = pincode;
	}

	/**
	 * @return the buildingName
	 */
	public String getBuildingName() {
		return buildingName;
	}

	/**
	 * @return the streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", streetName=" + streetName + ", pincode=" + pincode + "]";
	}

}
