package com.barclayscard.customercommand.events;

import java.util.Date;


/**
 * This is the event class for updation of date of birth
 */
public class DobUpdatedEvent extends AbstractEvent {

	private static final long serialVersionUID = 1L;
	private final Date dob;

	public DobUpdatedEvent(String id, Date dob) {
		super(id);
		this.dob = dob;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

}
