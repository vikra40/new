package com.barclayscardcustomerquery;

import static org.mockito.Mockito.mock;

import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.barclayscard.customerquery.domain.Address;
import com.barclayscard.customerquery.event.AddressUpdatedEvent;
import com.barclayscard.customerquery.event.CustomerAddedEvent;
import com.barclayscard.customerquery.handler.CustomerViewEventHandler;
import com.barclayscard.customerquery.repository.CustomerRepository;
@SpringBootConfiguration
@RunWith(SpringRunner.class)
@SpringBootTest
public class BarclaysCardCustomerQueryMicroserviceApplicationTests {
	
	
	static CustomerViewEventHandler eventHandler = new CustomerViewEventHandler();
	Date date = new Date();
	Address address = new Address("abc", "wer", "123");
	static CustomerRepository mockedBookDAL;
	@BeforeClass
	public static void setUp(){
		 mockedBookDAL = mock(CustomerRepository.class);
	
		  eventHandler.setCustomerRepository(mockedBookDAL);

	}
	
	@Test
	public void testEventListenerforCustomerAddEvent() {
	  
	  CustomerAddedEvent mockEvent = new CustomerAddedEvent("1","joy", "Verr", "1234567890", "abc@gmail.com", address, date);

	  eventHandler.handle(mockEvent);

	}
	
	
	/*@Test
	public void testEventListenerforAddressUpdatedEvent() {
	  AddressUpdatedEvent mockEvent = new AddressUpdatedEvent("1",address);

	  eventHandler.handle(mockEvent);

	}*/
	
}