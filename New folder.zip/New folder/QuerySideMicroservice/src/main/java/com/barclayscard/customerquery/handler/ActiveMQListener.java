package com.barclayscard.customerquery.handler;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.apache.activemq.command.Message;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ActiveMQListener {

/*  public ActiveMQListener(){
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("failover:tcp://localhost:61616");
		Connection connection = (Connection) connectionFactory.createConnection();
		connection.start();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination destination = session.createQueue("activemq");
		producer = session.createProducer(destination);
		producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT); 
	}*/
	@JmsListener(destination = "activemq")
	public void receiveMessage(final Message jsonMessage) throws JMSException {
		String messageData = null;
		System.out.println("Received message " + jsonMessage);
		String response = null;
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			messageData = textMessage.getText();
			System.out.println("=======actual message is ======="+messageData);
			//Map map = new Gson().fromJson(message, Map.class);
			//response  = "Hello " + map.get("name");
		}
		//return response;
	}
}
