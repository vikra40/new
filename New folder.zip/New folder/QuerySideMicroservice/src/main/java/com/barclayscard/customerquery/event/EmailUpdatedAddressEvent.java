package com.barclayscard.customerquery.event;

/**
 * This is the event class for Address updation for a customer
 *
 */
public class EmailUpdatedAddressEvent extends AbstractEvent {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String emailaddress;

	public EmailUpdatedAddressEvent(String id, String emailaddress) {
		super(id);
		this.emailaddress = emailaddress;
	}


	public String getEmailaddress() {
		return emailaddress;
	}
	
	
}
