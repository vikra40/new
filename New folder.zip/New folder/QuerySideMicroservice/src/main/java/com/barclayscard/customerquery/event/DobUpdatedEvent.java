package com.barclayscard.customerquery.event;
/**
 * This is the event class for Date of birth updation for a customer
 *
 */
public class DobUpdatedEvent extends AbstractEvent {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String dob;


	public String getDob() {
		return dob;
	}

	public DobUpdatedEvent(String id, String dob) {
		super(id);
		this.dob = dob;
	}
	
	
}
