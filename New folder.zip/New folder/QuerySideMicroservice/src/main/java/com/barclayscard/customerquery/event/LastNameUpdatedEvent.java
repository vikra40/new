package com.barclayscard.customerquery.event;
/**
 * This is the event class for Last name updation for a customer
 *
 */
public class LastNameUpdatedEvent extends AbstractEvent {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String last_name;

	public LastNameUpdatedEvent(String id, String last_name) {
		super(id);
		this.last_name = last_name;
	}


	public String getLast_name() {
		return last_name;
	}
	

}
