package com.barclayscard.customerquery.event;
/**
 * This is the event class for First name updation for a customer
 *
 */
public class FirstNameUpdatedEvent extends AbstractEvent {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String first_name;

	public String getFirst_name() {
		return first_name;
	}
	public FirstNameUpdatedEvent(String id, String first_name) {
		super(id);
		this.first_name = first_name;
	}
	
}
