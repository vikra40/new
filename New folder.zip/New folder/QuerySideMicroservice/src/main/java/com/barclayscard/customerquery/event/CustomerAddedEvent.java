package com.barclayscard.customerquery.event;

import java.util.Date;

import org.axonframework.domain.EventMessage;

import com.barclayscard.customerquery.domain.Address;



public class CustomerAddedEvent extends AbstractEvent{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private  String firstName;

	private  String lastName;

	private  String mobileNumber;

	private  String emailAddress;

	private  Address address;

	private  Date dob;

	public CustomerAddedEvent(){
		
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	public CustomerAddedEvent(String id, String firstName, String lastName, String mobileNumber, String emailAddress,
			Address address, Date dob) {
		super(id);
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailAddress = emailAddress;
		this.address = address;
		this.dob = dob;
	}

}
