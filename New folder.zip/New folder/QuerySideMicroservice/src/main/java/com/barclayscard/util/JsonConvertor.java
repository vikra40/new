package com.barclayscard.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonConvertor {

	public static String convertObjectToJSON(Object object) {

		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = "";

		try {

			jsonInString = mapper.writeValueAsString(object);

		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}

		return jsonInString;
	}
}
