package com.barclayscard.customerquery.handler;


import org.axonframework.eventhandling.annotation.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.barclayscard.customerquery.event.AddressUpdatedEvent;
import com.barclayscard.customerquery.event.CustomerAddedEvent;
import com.barclayscard.customerquery.event.EmailAddressUpdatedEvent;
import com.barclayscard.customerquery.event.MobileNumberUpdatedEvent;

@Component
public class EventLoggingHandler {

	private static final Logger LOG = LoggerFactory.getLogger(EventLoggingHandler.class);
	private static final String IID = String.valueOf(Double.valueOf(Math.random() * 1000).intValue());

	@EventHandler
	public void handle(CustomerAddedEvent event) {
		LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getFirstName(),
				event.getLastName(), event.getMobileNumber(), event.getEmailAddress(), event.getAddress(),
				event.getDob());
	}

	@EventHandler
	public void handle(MobileNumberUpdatedEvent event) {
		LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getMobileNumber());
	}

	@EventHandler
	public void handle(AddressUpdatedEvent event) {

		LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getAddress());
	}

	@EventHandler
	public void handle(EmailAddressUpdatedEvent event) {

		LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getEmailAddress());
	}
}
