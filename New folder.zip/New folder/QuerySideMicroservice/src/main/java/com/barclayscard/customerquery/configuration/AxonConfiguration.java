package com.barclayscard.customerquery.configuration;
import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.axonframework.auditing.AuditLogger;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.SimpleEventBus;
import org.axonframework.eventhandling.annotation.AnnotationEventListenerAdapter;
import org.axonframework.eventhandling.annotation.AnnotationEventListenerBeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.listener.SimpleMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;

import com.barclayscard.customerquery.handler.CustomerViewEventHandler;



@Configuration
class AxonConfiguration {
	private static final String DEFAULT_BROKER_URL = "tcp://localhost:61616";
    
	/*    private static final String ORDER_QUEUE = "order-queue";
	    private static final String ORDER_RESPONSE_QUEUE = "order-response-queue";*/
	   
	    @Bean
	    public ConnectionFactory connectionFactory(){
	        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
	        connectionFactory.setBrokerURL(DEFAULT_BROKER_URL);
	        connectionFactory.setPassword("admin");
		    connectionFactory.setUserName("admin");
	        return connectionFactory;
	    }
	 
	    /*
	     * Unused.
	     */
	    @Bean
	    public ConnectionFactory cachingConnectionFactory(){
	        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
	        connectionFactory.setTargetConnectionFactory(connectionFactory());
	        connectionFactory.setSessionCacheSize(10);
	        return connectionFactory;
	    }
    @Bean
	public EventBus eventBus() {
    	EventBus eventBus = new SimpleEventBus();
       // eventBus.subscribe(new AnnotationEventListenerAdapter(new CustomerViewEventHandler()));

		return eventBus;
	}
    
    @Bean
	public AnnotationEventListenerBeanPostProcessor annotationEventListenerBeanPostProcessor() {
		AnnotationEventListenerBeanPostProcessor processor = new AnnotationEventListenerBeanPostProcessor();
		processor.setEventBus(eventBus());

		return processor;
	}
    
  /*  @Bean
    public MessageListenerAdapter adapter() {
        MessageListenerAdapter messageListener
                = new MessageListenerAdapter();
        messageListener.setDefaultListenerMethod("log");
        return messageListener;
    }

    @Bean
    public SimpleMessageListenerContainer container(MessageListenerAdapter messageListener,
                                             ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setMessageListener(messageListener);
        container.setConnectionFactory(connectionFactory);
        container.setDestinationName("activemq");
        return container;
    }*/
/*    @Bean
    public AnnotationEventListenerAdapter annotationEventListenerAdapter(){
    	AnnotationEventListenerAdapter annotationEventListenerAdapter = new AnnotationEventListenerAdapter(annotationEventListenerBeanPostProcessor());
    	 annotationEventListenerAdapter.subscribe(new CustomerViewEventHandler(), eventBus());
    	 return annotationEventListenerAdapter;
    }*/
  //  AnnotationEventListenerAdapter.subscribe(new EventContainer(), eventBus());

	/*String password="pass";
	char[] pass=password.toCharArray();
	    @Autowired
	    public Mongo mongo;


		@Value("${mongodb.dbname}")
		private String mongoDbName;

		@Value("${mongodb.events.collection.name}")
		private String eventsCollectionName;

		@Value("${mongodb.events.snapshot.collection.name}")
		private String snapshotCollectionName;



	    @Bean
	    JacksonSerializer axonJsonSerializer() {
	        return new JacksonSerializer();
	    }


	    @Bean
	    EventBus eventBus() {
	        return new ClusteringEventBus(new DefaultClusterSelector());
	    }

	    @Bean(name = "axonMongoTemplate")
	    MongoTemplate axonMongoTemplate() {
	        MongoTemplate template =new DefaultMongoTemplate(mongo, mongoDbName, eventsCollectionName, snapshotCollectionName, null, null);// new DefaultMongoTemplate(mongo,
	        		//mongoDbName, eventsCollectionName, snapshotCollectionName, null, null);
	        System.out.println("Db "+template.domainEventCollection().getDB().getName());
	        return template;
	    }
	    
	 */


	 /*   @Bean
	    EventStore eventStore() {
	        MongoEventStore eventStore = new MongoEventStore(axonJsonSerializer(), axonMongoTemplate());
	        return eventStore;
	    }*/

/*	    @Bean
	    EventSourcingRepository<CustomerAggregate> customerEventSourcingRepository() {
	        EventSourcingRepository<CustomerAggregate> repo = new EventSourcingRepository<CustomerAggregate>(CustomerAggregate.class, eventStore());
	        repo.setEventBus(eventBus());
	        return repo;
	    }*/

/*	    @Bean
	    CommandBus commandBus() {
	        SimpleCommandBus commandBus = new SimpleCommandBus();
	        return commandBus;
	    }

	    @Bean
	    CommandGatewayFactoryBean<CommandGateway> commandGatewayFactoryBean() {
	        CommandGatewayFactoryBean<CommandGateway> factory = new CommandGatewayFactoryBean<CommandGateway>();
	        factory.setCommandBus(commandBus());
	        return factory;
	    }

	   
	    *//**
	     * This method allows Axon to automatically find your @CommandHandler's
	     *
	     * @return
	     *//*
	    @Bean
	    AnnotationCommandHandlerBeanPostProcessor commandHandlerBeanPostProcessor() {
	        AnnotationCommandHandlerBeanPostProcessor proc = new AnnotationCommandHandlerBeanPostProcessor();
	        proc.setCommandBus(commandBus());
	        return proc;
	    }
*/
	    /**
	     * This method registers your Aggregate Root as a @CommandHandler
	     *
	     * @return
	     */
/*	    @Bean
	    AggregateAnnotationCommandHandler<CustomerAggregate> customerAggregateCommandHandler() {
	        AggregateAnnotationCommandHandler<CustomerAggregate> handler = new AggregateAnnotationCommandHandler<CustomerAggregate>(
	        		CustomerAggregate.class,
	                customerEventSourcingRepository(),
	                commandBus());
	        return handler;
	    }*/
	    
	 /*   @Bean
	    AnnotationEventListenerBeanPostProcessor annotationEventListenerBeanPostProcessor() {
	        AnnotationEventListenerBeanPostProcessor listener = new AnnotationEventListenerBeanPostProcessor();
	        listener.setEventBus(eventBus());
	        System.out.println("event listener "+listener.getClass() + "  "+listener.isRunning());
	        return listener;
	    }
*/
	}
