package com.barclayscard.customerquery.event;

public class MobileNumberUpdatedEvent extends AbstractEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String mobileNumber;

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	public MobileNumberUpdatedEvent(String id, String mobileNumber) {
		super(id);
		this.mobileNumber = mobileNumber;
	}

}
