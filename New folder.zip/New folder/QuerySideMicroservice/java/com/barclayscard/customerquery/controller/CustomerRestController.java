package com.barclayscard.customerquery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.barclayscard.customerquery.domain.Customer;
import com.barclayscard.customerquery.repository.CustomerRepository;

@RestController
@RequestMapping("/customers")
public class CustomerRestController {
	@Autowired
	CustomerRepository customerRepository;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Customer customerFind(@PathVariable(value = "id") String id) {
		Customer customers = customerRepository.findById(id);
System.out.println(""+customers.getId() +" id is "+ id);
		return customers;
	}
}
