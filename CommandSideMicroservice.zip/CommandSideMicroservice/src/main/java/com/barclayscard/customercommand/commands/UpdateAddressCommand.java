package com.barclayscard.customercommand.commands;


import org.axonframework.commandhandling.model.AggregateIdentifier;

import com.barclayscard.customercommand.commands.valueobjects.Address;

public class UpdateAddressCommand {
	@AggregateIdentifier
	private final String id;
	
	private final Address address;

	public UpdateAddressCommand(String id, Address address) {
		super();
		this.id = id;
		this.address = address;
	}

	public String getId() {
		return id;
	}

	public Address getAddress() {
		return address;
	}
	
	
}
