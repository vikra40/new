package com.barclayscard.customercommand.commands;

import org.axonframework.commandhandling.model.AggregateIdentifier;

public class UpdateMobileNumberCommand {

	@AggregateIdentifier
	private final String id;
	
	private final String mobilenumber;

	public String getId() {
		return id;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public UpdateMobileNumberCommand(String id, String mobilenumber) {
		super();
		this.id = id;
		this.mobilenumber = mobilenumber;
	}
	
	
	
}
