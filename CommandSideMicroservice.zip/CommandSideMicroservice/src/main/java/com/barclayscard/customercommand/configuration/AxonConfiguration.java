package com.barclayscard.customercommand.configuration;

import java.util.Arrays;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.eventsourcing.eventstore.EventStorageEngine;
import org.axonframework.mongo.eventsourcing.eventstore.DefaultMongoTemplate;
import org.axonframework.mongo.eventsourcing.eventstore.MongoEventStorageEngine;
import org.axonframework.mongo.eventsourcing.eventstore.MongoFactory;
import org.axonframework.mongo.eventsourcing.eventstore.MongoTemplate;
import org.axonframework.mongo.eventsourcing.eventstore.documentperevent.DocumentPerEventStorageStrategy;
import org.axonframework.serialization.Serializer;
import org.axonframework.spring.config.AnnotationDriven;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;

/**
 * Created by ben on 
 */
@Configuration
@AnnotationDriven
@ComponentScan
@EnableJms
public class AxonConfiguration {
	 @Value("${mongodb.url}")
	    private String mongoUrl;

	    @Value("${mongodb.dbname}")
	    private String mongoDbName;

	    @Value("${mongodb.events.collection.name}")
	    private String eventsCollectionName;

	    @Value("${mongodb.events.snapshot.collection.name}")
	    private String snapshotCollectionName;

	    @Value("${spring.activemq.broker-url}")
	    private String hostname;
	    
	    @Value("${spring.activemq.user}")
	    private String username;

	    @Value("${spring.activemq.password}")
	    private String password;
	/*
	    @Value("${spring.application.exchange}")
	    private String exchangeName;*/

	    @Value("${spring.activemq.queue.name}")
	    private String queueName;

	    /*@Bean
	    public Serializer axonJsonSerializer() {
	        return new JacksonSerializer();
	    }*/

	    @Bean
	    public EventStorageEngine eventStorageEngine(Serializer serializer){
	        return new MongoEventStorageEngine(
	                serializer,null, axonMongoTemplate(), new DocumentPerEventStorageStrategy());
	    }

	    @Bean(name = "axonMongoTemplate")
	    public MongoTemplate axonMongoTemplate() {
	        MongoTemplate template = new DefaultMongoTemplate(mongoClient(), mongoDbName, eventsCollectionName, snapshotCollectionName);
	        return template;
	    }

	    @Bean
	    public MongoClient mongoClient(){
	        MongoFactory mongoFactory = new MongoFactory();
	        mongoFactory.setMongoAddresses(Arrays.asList(new ServerAddress(mongoUrl)));
	        return mongoFactory.createMongo();
	    }

	    /*@Bean
	    public SagaStore sagaStore(){
	        org.axonframework.mongo.eventhandling.saga.repository.MongoTemplate mongoTemplate =
	                new org.axonframework.mongo.eventhandling.saga.repository.DefaultMongoTemplate(mongoClient());
	        return new MongoSagaStore(mongoTemplate, axonJsonSerializer());
	    }*/
	    
	    
		@Bean
		public CommandBus commandBus() {
			SimpleCommandBus commandBus = new SimpleCommandBus();
			//commandBus.setHandlerInterceptors(Arrays.asList(new BeanValidationInterceptor()));
			return commandBus;
		}

		/*@Bean
		public EventBus eventBus() {
			return new SimpleEventBus();
		}*/
		
		/*@Bean
		public CommandGatewayFactoryBean<CommandGateway> commandGatewayFactoryBean() {
			CommandGatewayFactoryBean<CommandGateway> factory = new CommandGatewayFactoryBean<CommandGateway>();
			factory.setCommandBus(commandBus());
			return factory;
		}*/
	    
	    @Bean
	    public ActiveMQQueue MyQueue(){
	    	System.out.println("in queue creation");
	        return new ActiveMQQueue(queueName);
	    }
	    
	    @Bean
		//public ConnectionFactory ConnectionFactory(@Value("${broker.url}") String url) throws JMSException {
		public ActiveMQConnectionFactory connectionFactory() throws JMSException{
	    	//ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("vm://localhost?broker.persistent=false");
			ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory("vm://localhost?broker.persistent=false");
			activeMQConnectionFactory.setBrokerURL(hostname);
			activeMQConnectionFactory.setPassword(username);
			activeMQConnectionFactory.setUserName(password);
			//activeMQConnectionFactory.createConnection();
			//activeMQConnectionFactory.createQueueConnection("admin", "admin");
			System.out.println("active mq================"+activeMQConnectionFactory.getBrokerURL()+activeMQConnectionFactory.getAuditDepth());
			return activeMQConnectionFactory;
			}
	    @Bean
	    public ConnectionFactory cachingConnectionFactory() throws JMSException{
	        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
	        connectionFactory.setTargetConnectionFactory(connectionFactory());
	      //  connectionFactory.setSessionCacheSize(10);
	        return connectionFactory;
	    }
		@Bean
		public JmsTemplate jmsTemplate() throws JMSException{
		    JmsTemplate template = new JmsTemplate();
		    template.setConnectionFactory(connectionFactory());
		    return template;
		}
		
		@Bean
		public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() throws JMSException {
		    DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		    factory.setConnectionFactory(connectionFactory());
		    factory.setConcurrency("1-1");
		    return factory;
		}

	}