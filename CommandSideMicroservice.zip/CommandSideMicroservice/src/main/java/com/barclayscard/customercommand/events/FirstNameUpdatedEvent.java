package com.barclayscard.customercommand.events;

public class FirstNameUpdatedEvent extends AbstractEvent {
	
	private final String first_name;

	public String getFirst_name() {
		return first_name;
	}
	public FirstNameUpdatedEvent(String id, String first_name) {
		super(id);
		this.first_name = first_name;
	}
	
}
