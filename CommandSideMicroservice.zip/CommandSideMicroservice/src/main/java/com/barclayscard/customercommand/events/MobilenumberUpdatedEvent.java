package com.barclayscard.customercommand.events;

public class MobilenumberUpdatedEvent extends AbstractEvent {
	
	private final String mobilenumber;

	public String getMobilenumber() {
		return mobilenumber;
	}

	public MobilenumberUpdatedEvent(String id,String mobilenumber) {
		super(id);
		this.mobilenumber = mobilenumber;
	}

}
