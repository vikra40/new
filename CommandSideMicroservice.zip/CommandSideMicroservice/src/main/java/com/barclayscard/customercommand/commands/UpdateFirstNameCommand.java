package com.barclayscard.customercommand.commands;

import org.axonframework.commandhandling.model.AggregateIdentifier;

public class UpdateFirstNameCommand {
	@AggregateIdentifier
	private final String id;
	
	private final String first_name;

	public String getId() {
		return id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public UpdateFirstNameCommand(String id, String first_name) {
		super();
		this.id = id;
		this.first_name = first_name;
	}
	
}
