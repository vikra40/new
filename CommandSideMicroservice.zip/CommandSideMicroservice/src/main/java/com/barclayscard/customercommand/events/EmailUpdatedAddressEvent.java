package com.barclayscard.customercommand.events;


public class EmailUpdatedAddressEvent extends AbstractEvent {
	
	private final String emailaddress;

	public EmailUpdatedAddressEvent(String id, String emailaddress) {
		super(id);
		this.emailaddress = emailaddress;
	}


	public String getEmailaddress() {
		return emailaddress;
	}
	
	
}
