package com.barclayscard.customercommand.events;


public class DobUpdatedEvent extends AbstractEvent {
	
	private final String dob;


	public String getDob() {
		return dob;
	}

	public DobUpdatedEvent(String id, String dob) {
		super(id);
		this.dob = dob;
	}
	
	
}
