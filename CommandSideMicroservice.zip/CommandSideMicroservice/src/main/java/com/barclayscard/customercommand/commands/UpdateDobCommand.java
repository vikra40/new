package com.barclayscard.customercommand.commands;

import org.axonframework.commandhandling.model.AggregateIdentifier;

public class UpdateDobCommand {
	@AggregateIdentifier
	private final String id;
	
	private final String dob;

	public String getId() {
		return id;
	}

	public String getDob() {
		return dob;
	}

	public UpdateDobCommand(String id, String dob) {
		super();
		this.id = id;
		this.dob = dob;
	}
	
	
}
