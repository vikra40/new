package com.barclayscard.customercommand.aggregates;
/*
import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;*/
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.barclayscard.customercommand.commands.AddCustomerCommand;
import com.barclayscard.customercommand.commands.UpdateAddressCommand;
import com.barclayscard.customercommand.commands.UpdateDobCommand;
import com.barclayscard.customercommand.commands.UpdateEmailAddressCommand;
import com.barclayscard.customercommand.commands.UpdateFirstNameCommand;
import com.barclayscard.customercommand.commands.UpdateLastNameCommand;
import com.barclayscard.customercommand.commands.UpdateMobileNumberCommand;
import com.barclayscard.customercommand.commands.valueobjects.Address;
import com.barclayscard.customercommand.events.AddressUpdatedEvent;
import com.barclayscard.customercommand.events.CustomerAddedEvent;
import com.barclayscard.customercommand.events.DobUpdatedEvent;
import com.barclayscard.customercommand.events.EmailUpdatedAddressEvent;
import com.barclayscard.customercommand.events.FirstNameUpdatedEvent;
import com.barclayscard.customercommand.events.LastNameUpdatedEvent;
import com.barclayscard.customercommand.events.MobilenumberUpdatedEvent;
import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.AggregateIdentifier;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.spring.stereotype.Aggregate;


@Aggregate
public class CustomerAggregate{

	private static final Logger LOG = LoggerFactory.getLogger(CustomerAggregate.class);
	
	@AggregateIdentifier
	private  String id;
	
	private  String first_name;
    
    private  String last_name;
    
    private  String mobile_number;
    
    private  String emailaddress;
    
    private  Address address;
    
    private  String dob;
	
	
	public CustomerAggregate(){
		
	}
	
	@CommandHandler
	public CustomerAggregate(AddCustomerCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'AddCustomerCommand' received.");
        LOG.debug("Queuing up a new CustomerAddedEvent for Customerid '{}'", command.getId());
        apply(new CustomerAddedEvent(command.getId(),command.getFirst_name(),command.getLast_name(),command.getMobile_number(),command.getEmailaddress(),command.getAddress(),command.getDob()));
	}
	
	@CommandHandler
	public CustomerAggregate(UpdateFirstNameCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'UpdateFirstNameCommand' received.");
        LOG.debug("Queuing up a new UpdateFirstNameCommand for Customerid '{}'", command.getId());
        apply(new FirstNameUpdatedEvent(command.getId(),command.getFirst_name()));
	}
	
	@CommandHandler
	public CustomerAggregate(UpdateLastNameCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'UpdateLastNameCommand' received.");
        LOG.debug("Queuing up a new UpdateLastNameCommand for Customerid '{}'", command.getId());
        apply(new LastNameUpdatedEvent(command.getId(),command.getLast_name()));
	}
	
	@CommandHandler
	public CustomerAggregate(UpdateMobileNumberCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'UpdateMobileNumberCommand' received.");
        LOG.debug("Queuing up a new UpdateMobileNumberCommand for Customerid '{}'", command.getId());
        apply(new MobilenumberUpdatedEvent(command.getId(),command.getMobilenumber()));
	}
	
	@CommandHandler
	public CustomerAggregate(UpdateDobCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'UpdateDobCommand' received.");
        LOG.debug("Queuing up a new DobUpdatedEvent for Customerid '{}'", command.getId());
        apply(new DobUpdatedEvent(command.getId(),command.getDob()));
	}	
	@CommandHandler
	public CustomerAggregate(UpdateEmailAddressCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'AddCustomerCommand' received.");
        LOG.debug("Queuing up a new EmailUpdatedAddressEvent for Customerid '{}'", command.getId());
        apply(new EmailUpdatedAddressEvent(command.getId(),command.getEmailaddress()));
       	}
	@CommandHandler
	public CustomerAggregate(UpdateAddressCommand command){
		System.out.println("======IN CUSTOMERAGGREGATE=====");
		LOG.debug("Command: 'AddCustomerCommand' received.");
        LOG.debug("Queuing up a new AddressUpdatedEvent for Customerid '{}'", command.getId());
        apply(new AddressUpdatedEvent(command.getId(),command.getAddress()));
       	}
	
	@EventSourcingHandler
	public void on(CustomerAddedEvent event){
		this.id = event.getId();
		this.first_name = event.getFirst_name();
		this.emailaddress=event.getEmailaddress();
		this.dob=event.getDob();
		this.mobile_number=event.getMobile_number();
		this.address=event.getAddress();
        LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getFirst_name(),event.getLast_name(),event.getMobile_number(),event.getEmailaddress(),event.getAddress(),event.getDob());
	}
	
	@EventSourcingHandler
	public void on(FirstNameUpdatedEvent event){
		this.id = event.getId();
		this.first_name = event.getFirst_name();
        LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getFirst_name());
	}
	
	@EventSourcingHandler
	public void on(LastNameUpdatedEvent event){
		this.id = event.getId();
		this.last_name = event.getLast_name();
		  LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getLast_name());
	}
	
	@EventSourcingHandler
	public void on(MobilenumberUpdatedEvent event){
		this.id = event.getId();
		this.mobile_number=event.getMobilenumber();
		 LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getMobilenumber());
	}
	
	@EventSourcingHandler
	public void on(DobUpdatedEvent event){
		this.id = event.getId();
		this.dob=event.getDob();
		 LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getDob());
	}
	
	@EventSourcingHandler
	public void on(AddressUpdatedEvent event){
		this.id = event.getId();
		this.address=event.getAddress();
		LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getAddress());
	}
	
	@EventSourcingHandler
	public void on(EmailUpdatedAddressEvent event){
		this.id = event.getId();
		this.emailaddress=event.getEmailaddress();
		LOG.debug("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(),event.getEmailaddress());
	}

	public static Logger getLog() {
		return LOG;
	}

	public String getId() {
		return id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public String getEmailaddress() {
		return emailaddress;
	}

	public Address getAddress() {
		return address;
	}

	public String getDob() {
		return dob;
	}
	
	
	
}
