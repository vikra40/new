package com.barclayscard.customercommand.eventhandler;


import org.axonframework.eventhandling.EventHandler;
//import org.axonframework.eventhandling.annotation.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.barclayscard.customercommand.events.AddressUpdatedEvent;
import com.barclayscard.customercommand.events.CustomerAddedEvent;
import com.barclayscard.customercommand.events.DobUpdatedEvent;
import com.barclayscard.customercommand.events.EmailUpdatedAddressEvent;
import com.barclayscard.customercommand.events.FirstNameUpdatedEvent;
import com.barclayscard.customercommand.events.LastNameUpdatedEvent;
import com.barclayscard.customercommand.events.MobilenumberUpdatedEvent;
/**
 * EventHandler's (a.k.a. EventListeners) are used to react to events and perform associated
 * actions.
 * Created by team
 */
@Component
public class EventLoggingHandler {

    private static final Logger LOG = LoggerFactory.getLogger(EventLoggingHandler.class);
    private static final String IID = String.valueOf(Double.valueOf(Math.random() * 1000).intValue());

    @EventHandler
    public void handle(CustomerAddedEvent event) {
        LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getFirst_name(),event.getLast_name(),event.getMobile_number(),event.getEmailaddress(),event.getAddress(),event.getDob());
    }
    
    @EventHandler
    public void handle(FirstNameUpdatedEvent event) {
        LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getFirst_name());
    }
    
    @EventHandler
    public void handle(LastNameUpdatedEvent event) {
        LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getLast_name());
    }
    
    @EventHandler
    public void handle(MobilenumberUpdatedEvent event) {
        LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getMobilenumber());
    }
    
    @EventHandler
    public void handle(DobUpdatedEvent event) {
    	LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getDob());
    }
    
    @EventHandler
    public void handle(AddressUpdatedEvent event) {

    	LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getAddress());
    }
    
    @EventHandler
    public void handle(EmailUpdatedAddressEvent event) {

    	LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(),event.getEmailaddress());
    }
}
