package com.barclayscard.customercommand.commands.valueobjects;


public class Address {
	
	private final String buildingname;
	
	private final String streetname;
	
	private final String pincode ;

	public Address(String buildingname, String streetname, String pincode) {
		super();
		this.buildingname = buildingname;
		this.streetname = streetname;
		this.pincode = pincode;
	}

	public String getBuildingname() {
		return buildingname;
	}

	public String getStreetname() {
		return streetname;
	}

	public String getPincode() {
		return pincode;
	}
	
	

}
