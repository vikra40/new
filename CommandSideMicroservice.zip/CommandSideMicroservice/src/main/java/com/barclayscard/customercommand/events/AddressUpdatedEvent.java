package com.barclayscard.customercommand.events;

import com.barclayscard.customercommand.commands.valueobjects.Address;

public class AddressUpdatedEvent extends AbstractEvent {
	
	private final Address address;

	public Address getAddress() {
		return address;
	}

	public AddressUpdatedEvent(String id,Address address) {
		super(id);
		this.address = address;
	}

}
