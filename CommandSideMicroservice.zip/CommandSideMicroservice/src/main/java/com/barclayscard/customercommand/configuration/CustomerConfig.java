package com.barclayscard.customercommand.configuration;

import org.axonframework.commandhandling.model.Repository;
import org.axonframework.eventsourcing.AggregateFactory;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.axonframework.spring.eventsourcing.SpringPrototypeAggregateFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.barclayscard.customercommand.aggregates.CustomerAggregate;


@Configuration
public class CustomerConfig {

	@Autowired
    private EventStore eventStore;

    @Bean
    @Scope("prototype")
    public CustomerAggregate productAggregate(){
        return new CustomerAggregate();
    }

    @Bean
    public AggregateFactory<CustomerAggregate> customerAggregateAggregateFactory(){
        SpringPrototypeAggregateFactory<CustomerAggregate> aggregateFactory = new SpringPrototypeAggregateFactory<>();
        aggregateFactory.setPrototypeBeanName("customerAggregate");
        return aggregateFactory;
    }

    @Bean
    public Repository<CustomerAggregate> customerAggregateRepository(){
        EventSourcingRepository<CustomerAggregate> repository = new EventSourcingRepository<CustomerAggregate>(
                customerAggregateAggregateFactory(),
                eventStore
        );
        return repository;
    }
}
