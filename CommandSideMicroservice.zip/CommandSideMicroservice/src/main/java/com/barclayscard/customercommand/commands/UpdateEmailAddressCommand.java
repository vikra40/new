package com.barclayscard.customercommand.commands;

import org.axonframework.commandhandling.model.AggregateIdentifier;

public class UpdateEmailAddressCommand {
	@AggregateIdentifier
	private final String id;
	
	private final String emailaddress;

	public UpdateEmailAddressCommand(String id, String emailaddress) {
		super();
		this.id = id;
		this.emailaddress = emailaddress;
	}

	public String getId() {
		return id;
	}

	public String getEmailaddress() {
		return emailaddress;
	}
	
	
}
