package com.barclayscard.customercommand.commands;

import org.axonframework.commandhandling.model.AggregateIdentifier;

public class UpdateLastNameCommand {
	
	@AggregateIdentifier
	private final String id;
	
	private final String last_name;

	public UpdateLastNameCommand(String id, String last_name) {
		super();
		this.id = id;
		this.last_name = last_name;
	}

	public String getId() {
		return id;
	}

	public String getLast_name() {
		return last_name;
	}
	

}
