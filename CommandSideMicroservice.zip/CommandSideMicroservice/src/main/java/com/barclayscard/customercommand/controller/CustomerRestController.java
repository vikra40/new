package com.barclayscard.customercommand.controller;

import javax.servlet.http.HttpServletResponse;

import org.axonframework.commandhandling.CommandExecutionException;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.commandhandling.model.ConcurrencyException;
//import org.axonframework.repository.ConcurrencyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.barclayscard.customercommand.commands.AddCustomerCommand;
import com.barclayscard.customercommand.commands.UpdateAddressCommand;
import com.barclayscard.customercommand.commands.UpdateDobCommand;
import com.barclayscard.customercommand.commands.UpdateEmailAddressCommand;
import com.barclayscard.customercommand.commands.UpdateFirstNameCommand;
import com.barclayscard.customercommand.commands.UpdateLastNameCommand;
import com.barclayscard.customercommand.commands.UpdateMobileNumberCommand;
import com.barclayscard.customercommand.commands.valueobjects.Address;
import com.barclayscard.customercommand.entity.Customer;
import com.barclayscard.customercommand.service.CustomerApplicationService;

@RestController
@RequestMapping("/")
public class CustomerRestController {

	

    private static final Logger LOG = LoggerFactory.getLogger(CustomerRestController.class);

    @Autowired
    CommandGateway commandGateway;
    
   
    @RequestMapping(value = "addcustomer", method = RequestMethod.GET)
    public void add(HttpServletResponse response) {
    	Customer customer  = new Customer("6","Vikram", "Verma", "9007865877", "abc@gmail.com", new Address("ABC", "xyz", "712121"), "31/08/1989" );
    	
    	LOG.debug("Adding customer [{}] '{}'",customer.getId(),customer.getFirst_name(),customer.getLast_name(),customer.getMobile_number(),customer.getEmailaddress(),customer.getAddress(),customer.getDob());

        try {
            AddCustomerCommand command = new AddCustomerCommand(customer.getId(),customer.getFirst_name(),customer.getLast_name(),customer.getMobile_number(),customer.getEmailaddress(),customer.getAddress(),customer.getDob());
            commandGateway.sendAndWait(command);
            LOG.info("Added Customer [{}] '{}'", customer.getId(),customer.getFirst_name(),customer.getLast_name(),customer.getMobile_number(),customer.getEmailaddress(),customer.getAddress(),customer.getDob());
            response.setStatus(HttpServletResponse.SC_CREATED);// Set up the 201 CREATED response
            return;
        } catch (AssertionError ae) {
            LOG.warn("Add Request failed - empty params?. [{}] '{}'", customer.getId(),customer.getFirst_name(),customer.getLast_name(),customer.getMobile_number(),customer.getEmailaddress(),customer.getAddress(),customer.getDob());
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        } catch (CommandExecutionException cex) {
            LOG.warn("Add Command FAILED with Message: {}", cex.getMessage());
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);

            if (null != cex.getCause()) {
                LOG.warn("Caused by: {} {}", cex.getCause().getClass().getName(), cex.getCause().getMessage());
                if (cex.getCause() instanceof ConcurrencyException) {
                    LOG.warn("A duplicate customer with the same ID [{}] already exists.", customer.getId());
                    response.setStatus(HttpServletResponse.SC_CONFLICT);
                }
            }
        }
    }
    
/*    @RequestMapping(value = "updatecustomer/firstname/{id}", method = RequestMethod.PUT)
    public void updateFirstName(@RequestParam("firstname") String firstname,@RequestParam("id") String id, HttpServletResponse response)
    {
    	
    	UpdateFirstNameCommand updatefirstnamecommand=new UpdateFirstNameCommand(id, firstname);
    	commandGateway.sendAndWait(updatefirstnamecommand);
    }
    
    @RequestMapping(value = "updatecustomer/lastname/{id}", method = RequestMethod.PUT)
    public void updateLastName(@RequestParam("lastname") String lastname,@PathVariable String id, HttpServletResponse response)
    {
    	UpdateLastNameCommand updatelastnamecommand=new UpdateLastNameCommand(id, lastname);
    	commandGateway.sendAndWait(updatelastnamecommand);
    }
    @RequestMapping(value = "updatecustomer/address/{id}", method = RequestMethod.PUT)
    public void updateAddress(@RequestBody Address address,@PathVariable String id, HttpServletResponse response)
    {
    	UpdateAddressCommand updateaddresscommand=new UpdateAddressCommand(id, address);
    	commandGateway.sendAndWait(updateaddresscommand);
    }
    @RequestMapping(value = "updatecustomer/emailaddress/{id}", method = RequestMethod.PUT)
    public void updateEmailAddress(@RequestParam("emailaddress") String emailaddress,@PathVariable String id, HttpServletResponse response)
    {
    	UpdateEmailAddressCommand updateemailaddresscommand=new UpdateEmailAddressCommand(id, emailaddress);
    	commandGateway.sendAndWait(updateemailaddresscommand);
    }
    @RequestMapping(value = "updatecustomer/dob/{id}", method = RequestMethod.PUT)
    public void updateDob(@RequestParam("dob") String dob,@PathVariable String id, HttpServletResponse response)
    {
    	UpdateDobCommand updatedobcommand=new UpdateDobCommand(id, dob);
    	commandGateway.sendAndWait(updatedobcommand);
    }
    @RequestMapping(value = "updatecustomer/mobilenumber/{id}", method = RequestMethod.PUT)
    public void updateMobileNumber(@RequestParam("mobilenumber") String mobilenumber,@PathVariable String id,HttpServletResponse response)
    {
    	UpdateMobileNumberCommand updatemobilecommand=new UpdateMobileNumberCommand(id, mobilenumber);
    	commandGateway.sendAndWait(updatemobilecommand);
    }
*/}
