package com.barclayscard.customercommand.commands;


import org.axonframework.commandhandling.TargetAggregateIdentifier;

import com.barclayscard.customercommand.commands.valueobjects.Address;

public class AddCustomerCommand {

	
	  	@TargetAggregateIdentifier
	    private final String id;
	  	
	    private final String first_name;
	    
	    private final String last_name;
	    
	    private final String mobile_number;
	    
	    private final String emailaddress;
	    
	   
	    private final Address address;
	    
	    private final String dob;

		public String getId() {
			return id;
		}

		public String getFirst_name() {
			return first_name;
		}

		public String getLast_name() {
			return last_name;
		}

		public String getMobile_number() {
			return mobile_number;
		}

		public String getEmailaddress() {
			return emailaddress;
		}

		public Address getAddress() {
			return address;
		}

		public String getDob() {
			return dob;
		}

		public AddCustomerCommand(String id, String first_name, String last_name, String mobile_number,
				String emailaddress, Address address, String dob) {
			super();
			this.id = id;
			this.first_name = first_name;
			this.last_name = last_name;
			this.mobile_number = mobile_number;
			this.emailaddress = emailaddress;
			this.address = address;
			this.dob = dob;
		}

}
