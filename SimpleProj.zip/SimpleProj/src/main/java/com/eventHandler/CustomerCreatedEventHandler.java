package com.eventHandler;

import javax.sql.DataSource;

import org.axonframework.domain.Message;
import org.axonframework.eventhandling.annotation.EventHandler;
import org.axonframework.eventhandling.annotation.Timestamp;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.event.CustomerCreatedEvent;
import com.model.Address;


@Component
public class CustomerCreatedEventHandler {

/*	@Autowired
    DataSource dataSource;
*/
	@EventHandler
    public void handleCustomerCreatedEvent(CustomerCreatedEvent event) {
       // JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        // Get the current states as reflected in the event
        String correlatedId = event.getCorrelatedId();
        String custId=event.getCustId();
        String name=event.getName();
        String dob=event.getDob();
        String email=event.getEmail();
        String mobileNumber=event.getMobileNumber();
        Address address=event.getAddress();
        
        System.out.println("===in CustomerCreatedEventHandler "+correlatedId +" "+custId +" "+name+" "+dob+" "+email+" "+mobileNumber+" "+address.getCity()+" "+address.getCountry()+" "+address.getPostalCode());
        
        /*// Update the view
        String updateQuery = "UPDATE account_view SET balance = ? WHERE account_no = ?";
        jdbcTemplate.update(updateQuery, new Object[]{newBalance, accountNo});

        System.out.println("Events Handled With EventMessage " + eventMessage.toString() + " at " + moment.toString());
*/    }


}
