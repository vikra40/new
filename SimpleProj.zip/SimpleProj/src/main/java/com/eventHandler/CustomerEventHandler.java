package com.eventHandler;

import org.axonframework.eventhandling.annotation.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.event.CustomerCreatedEvent;


@Component
public class CustomerEventHandler {
	 private static final Logger LOG = LoggerFactory.getLogger(CustomerEventHandler.class);
	    private static final String IID = String.valueOf(Double.valueOf(Math.random() * 1000).intValue());

	    @EventHandler
	    public void handle(CustomerCreatedEvent event) {
	        LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getClass().getSimpleName(), event.getCustId(), event.getName());
	    }


}
