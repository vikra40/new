package com.event;

import java.time.LocalDateTime;
import java.time.ZoneId;

import com.command.CreateCustomerCommand;
import com.eventHandler.CustomerCreatedEventHandler;
import com.model.Address;

public class CustomerCreatedEvent {

	private String correlatedId;
	private String custId;
	private String name;
	private String dob;
	private String email;
	private String mobileNumber;
	Address address;
    private final long timeStamp;

	public CustomerCreatedEvent(String correlatedId, CreateCustomerCommand command) {
		this.correlatedId =correlatedId;
		this.custId=command.getCustId();
		this.name=command.getName();
		this.dob=command.getDob();
		this.email=command.getEmail();
		this.mobileNumber=command.getMobileNumber();
		this.address=command.getAddress();

		ZoneId zoneId = ZoneId.systemDefault();
        this.timeStamp = LocalDateTime.now().atZone(zoneId).toEpochSecond();	
        System.out.println("===in CustomerCreatedEvent "+correlatedId +" "+custId +" "+name+" "+dob+" "+email+" "+mobileNumber+" "+address.getCity()+" "+address.getCountry()+" "+address.getPostalCode()+" "+timeStamp);
        
        }

	public String getCorrelatedId() {
		return correlatedId;
	}

	public String getCustId() {
		return custId;
	}

	public String getName() {
		return name;
	}

	public String getDob() {
		return dob;
	}

	public String getEmail() {
		return email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public Address getAddress() {
		return address;
	}

	public long getTimeStamp() {
		return timeStamp;
	}
	


}
