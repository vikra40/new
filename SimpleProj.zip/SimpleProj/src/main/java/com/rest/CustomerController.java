package com.rest;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.command.CreateCustomerCommand;
import com.model.Customer;



@RestController
public class CustomerController {
	

    @Autowired
    private CommandGateway commandGateway;

	 @RequestMapping("/createCustomer")
	    @Transactional
	    @ResponseBody
	    public void doCreateCustomer(@RequestParam("custId") String custId, @RequestParam("name") String name, @RequestParam("dob") String dob,
	    		@RequestParam("email") String email,@RequestParam("mobileNumber") String mobileNumber,@RequestParam("city") String city
	    		,@RequestParam("postalCode") String postalCode,@RequestParam("country") String country) {
		 Customer customer = new Customer();
		 customer.setCustId(custId);
		 customer.setName(name);customer.setDob(dob);customer.setEmail(email);customer.setMobileNumber(mobileNumber);customer.getAddress().setCity(city);
		 customer.getAddress().setPostalCode(postalCode);customer.getAddress().setCountry(country);
		 
	        CreateCustomerCommand customerCreated = new CreateCustomerCommand(customer);
	        commandGateway.send(customerCreated);
	    }


}
