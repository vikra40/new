package com.rest;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.domain.DefaultIdentifierFactory;
import org.axonframework.domain.IdentifierFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.command.CreateCustomerCommand;
import com.model.Customer;



@RestController
public class CustomerController {
	

	private final IdentifierFactory identifierFactory = new DefaultIdentifierFactory();
    @Autowired
    private CommandGateway commandGateway;

	 @RequestMapping("/createCustomer")
	   // @Transactional
	    //@ResponseBody
	   /* public void doCreateCustomer(@RequestParam("custId") String custId, @RequestParam("name") String name, @RequestParam("dob") String dob,
	    		@RequestParam("email") String email,@RequestParam("mobileNumber") String mobileNumber,@RequestParam("city") String city
	    		,@RequestParam("postalCode") String postalCode,@RequestParam("country") String country) {
		 Customer customer = new Customer();
		 customer.setCustId(custId);
		 customer.setName(name);customer.setDob(dob);customer.setEmail(email);customer.setMobileNumber(mobileNumber);customer.getAddress().setCity(city);
		 customer.getAddress().setPostalCode(postalCode);customer.getAddress().setCountry(country);
		 
	        CreateCustomerCommand customerCreated = new CreateCustomerCommand(customer);
	        commandGateway.send(customerCreated);
	    }
*/

	 public void doCreateCustomer(@RequestBody Customer customer){
		 
	        commandGateway.send(new CreateCustomerCommand(identifierFactory.generateIdentifier().toString(),customer));

	 }
}
