package com.domain;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.command.CreateCustomerCommand;
import com.event.CustomerCreatedEvent;
import com.model.Address;


public class CustomerAggregate extends AbstractAnnotatedAggregateRoot {
    private static final long serialVersionUID = 8723320580782813954L;
	private static final Logger LOG = LoggerFactory.getLogger(CustomerAggregate.class);
	

    @AggregateIdentifier
   // private String correlatedId;

    private String custId;
	private String name;
	private String dob;
	private String email;
	private String mobileNumber;
	Address address;
	private String creationDate;

    
    public CustomerAggregate() {
    }

    
    @CommandHandler
  public CustomerAggregate(CreateCustomerCommand command) {

    	LOG.debug("Command: 'AddCustomerCommand' received.");
        LOG.debug("Queuing up a new CustomerAddedEvent for product '{}'", command.getCustId());
        apply(new CustomerCreatedEvent(command.getCustId(), command.getName(),command.getDob(),command.getEmail(),command.getMobileNumber(),command.getAddress(),command.getCreationDate()));
	}


  @EventSourcingHandler
  public void on(CustomerCreatedEvent event) {
	  //this.correlatedId = event.getCorrelatedId();
		this.custId = event.getCustId();
		this.name = event.getName();
		this.dob = event.getDob();
		this.email = event.getEmail();
		this.mobileNumber = event.getMobileNumber();
		this.address = event.getAddress();
		this.creationDate = event.getCreationDate();

		
       }
  

  /*
  @EventHandler
  public void updateCustomerName(String correlatedId, String custId,String name,String creationDate) {
  	System.out.println("in aggregate method"+custId + "  "+name);
	  if(!(this.name.equals(name))){
  		apply(new UpdatedCustomerNameEvent(correlatedId,custId, name,creationDate));
  	}    	
  }
/*  public CustomerAggregate(CreateCustomerCommand command) {
    	System.out.println("==========in aggregate====");
        apply(new CustomerCreatedEvent(command.getCorrelatedId(), command));
    }
    @EventHandler
    void on(CustomerCreatedEvent event){
    	System.out.println("in event handler");
    	this.correlatedId=event.getCorrelatedId();
    	//repository.add("ABC"+event);
    	//apply(event);
    	
    }
    

    @EventSourcingHandler
    public void applyCustomerCreation(CreateCustomerCommand command) {
    	apply(new CustomerCreatedEvent(this.correlatedId, command));
    }
    public void createCustomer(CreateCustomerCommand command) {

        if (Double.compare(debitAmount, 0.0d) > 0 &&
                this.balance - debitAmount > -1) {
            *//**
             * Instead of changing the state directly we apply an event
             * that conveys what happened.
             *
             * The event thus applied is stored.
             *//*
            apply(new CustomerCreatedEvent(this.correlatedId, command));
        } else {
            throw new IllegalArgumentException("Cannot debit with the amount");
        }

    }
    
       public void setIdentifier(String id) {
        this.accountNo = id;
    }

*/    @Override
    public String getIdentifier() {
        return this.custId;
	//return this.custId;
    }


			public String getName() {
				return name;
			}


			public String getDob() {
				return dob;
			}


			public String getEmail() {
				return email;
			}


			public String getMobileNumber() {
				return mobileNumber;
			}


			public Address getAddress() {
				return address;
			}


			public String getCreationDate() {
				return creationDate;
			}



/*
			public String getCustId() {
				return this.custId;
			}*/

}

