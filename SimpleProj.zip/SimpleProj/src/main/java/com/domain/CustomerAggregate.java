package com.domain;

import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;

import com.command.CreateCustomerCommand;
import com.event.CustomerCreatedEvent;


public class CustomerAggregate extends AbstractAnnotatedAggregateRoot {
    private static final long serialVersionUID = 8723320580782813954L;

    @AggregateIdentifier
    private String correlatedId;

    public CustomerAggregate() {
    }
/*
    public CustomerAggregate(String accountNo) {
        apply(new AccountCreatedEvent(accountNo));
    }
    */

    @EventSourcingHandler
    public void applyCustomerCreation(CreateCustomerCommand command) {
    	apply(new CustomerCreatedEvent(this.correlatedId, command));
    }
    public void createCustomer(CreateCustomerCommand command) {

       /* if (Double.compare(debitAmount, 0.0d) > 0 &&
                this.balance - debitAmount > -1) {
            *//**
             * Instead of changing the state directly we apply an event
             * that conveys what happened.
             *
             * The event thus applied is stored.
             *//*
         */   apply(new CustomerCreatedEvent(this.correlatedId, command));
      /*  } else {
            throw new IllegalArgumentException("Cannot debit with the amount");
        }
*/
    }
    
/*       public void setIdentifier(String id) {
        this.accountNo = id;
    }
*/
    @Override
    public Object getIdentifier() {
        return correlatedId;
    }
}

