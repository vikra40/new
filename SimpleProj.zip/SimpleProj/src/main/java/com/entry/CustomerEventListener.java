/*
 * Copyright (c) 2016-2026. DesignThoughts Axon Sample
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.entry;

import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.annotation.EventHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.event.CustomerCreatedEvent;

/**
 * @author Thomas Yuan
 */

@Component
public class CustomerEventListener {
	
	/*@Autowired
	EventBus eventBus;
	@Autowired
	private CustomerEntryRepository customerEntryRepository;

    @EventHandler
    public void handle(CustomerCreatedEvent event) {
    
    	System.out.println("Before save to db");
    	
    	

    	customerEntryRepository.save(new CustomerEntry(event.getCorrelatedId(),
    			event.getCustId(),
    			event.getName(),
    			event.getDob(),
    			event.getEmail(),
    			event.getMobileNumber(),
    			event.getAddress(),
    			event.getCreationDate()
    			));
    	System.out.println("After saved to db "+event.getCustId());

    }
*/  /*
    @EventHandler
    public void handle(CustomerActivatedEvent event) {
    	CustomerEntry customerEntry = customerEntryRepository.findByIdentifier(event.getCustomerId().toString());
    	customerEntry.setStatus(Status.ACTIVE.toString());
    	customerEntryRepository.save(customerEntry);
    }
    
    @EventHandler
    public void handle(CustomerAddressAddedEvent event) {
    	CustomerEntry customerEntry = customerEntryRepository.findByIdentifier(event.getCustomerId().toString());
    	customerEntry.addAddress(event.getAddress().getBuilding(),
    			event.getAddress().getStreet(),
    			event.getAddress().getCity(),
    			event.getAddress().getCountry()
    			);
    	customerEntryRepository.save(customerEntry);
    }*/
}
