package com.command;

import com.model.Address;

public class UpdateCustomerNameCommand {

	private String correlatedId;
	private String custId;
	private String name;
	
	private String creationDate;

	public UpdateCustomerNameCommand(String correlatedId, String custId, String name, String creationDate) {
		this.correlatedId = correlatedId;
		this.custId = custId;
		this.name = name;
		this.creationDate = creationDate;
    	System.out.println("in UpdateCustomerNameCommand  "+custId+"  "+name);

	}

	public String getCorrelatedId() {
		return correlatedId;
	}

	public void setCorrelatedId(String correlatedId) {
		this.correlatedId = correlatedId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	
	
}
