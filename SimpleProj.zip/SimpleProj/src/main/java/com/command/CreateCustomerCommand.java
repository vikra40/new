package com.command;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;

import com.model.Address;

public class CreateCustomerCommand {
	
	//Customer customer;
	//private String correlatedId;
	@TargetAggregateIdentifier
	private String custId;
	private String name;
	private String dob;
	private String email;
	private String mobileNumber;
	Address address;
	private String creationDate;
	public CreateCustomerCommand(/*String correlatedId,*/ String custId, String name, String dob, String email,
			String mobileNumber, Address address, String creationDate) {
		//this.correlatedId = correlatedId;
		this.custId = custId;
		this.name = name;
		this.dob = dob;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.creationDate = creationDate;
		System.out.println("in command======"+creationDate);
	}
	/*public String getCorrelatedId() {
		return correlatedId;
	}
	public void setCorrelatedId(String correlatedId) {
		this.correlatedId = correlatedId;
	}*/
	public String getCustId() {
		return custId;
	}
	/*public void setCustId(String custId) {
		this.custId = custId;
	}*/
	public String getName() {
		return name;
	}
	/*public void setName(String name) {
		this.name = name;
	}*/
	public String getDob() {
		return dob;
	}
	/*public void setDob(String dob) {
		this.dob = dob;
	}*/
	public String getEmail() {
		return email;
	}
	/*public void setEmail(String email) {
		this.email = email;
	}*/
	public String getMobileNumber() {
		return mobileNumber;
	}
	/*public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}*/
	public Address getAddress() {
		return address;
	}
	/*public void setAddress(Address address) {
		this.address = address;
	}
	*/public String getCreationDate() {
		return creationDate;
	}
	/*public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
*/
}
