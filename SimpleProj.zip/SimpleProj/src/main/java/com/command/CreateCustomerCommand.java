package com.command;

import com.model.Address;
import com.model.Customer;

public class CreateCustomerCommand {
	
	//Customer customer;
	private String custId;
	private String name;
	private String dob;
	private String email;
	private String mobileNumber;
	Address address;
	public CreateCustomerCommand(Customer customer){
		this.custId=customer.getCustId();
		this.name=customer.getName();
		this.dob=customer.getDob();
		this.email=customer.getEmail();
		this.mobileNumber=customer.getMobileNumber();
		this.address=customer.getAddress();
        System.out.println("===in CreateCustomerCommand "+custId +" "+name+" "+dob+" "+email+" "+mobileNumber+" "+address.getCity()+" "+address.getCountry()+" "+address.getPostalCode());

		
	}
	
	public String getCustId() {
		return custId;
	}
	public String getName() {
		return name;
	}
	public String getDob() {
		return dob;
	}
	public String getEmail() {
		return email;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public Address getAddress() {
		return address;
	}

	

}
