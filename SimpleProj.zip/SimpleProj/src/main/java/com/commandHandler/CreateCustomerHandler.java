package com.commandHandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.command.CreateCustomerCommand;
import com.command.UpdateCustomerNameCommand;
import com.domain.CustomerAggregate;
import com.event.CustomerCreatedEvent;




@Component
public class CreateCustomerHandler {
   /* private EventSourcingRepository<CustomerAggregate> customerRepository;

    
    @CommandHandler
    public void handle(CreateCustomerCommand command) {
    	CustomerAggregate customer = new CustomerAggregate(
                command.getCorrelatedId(),
                command.getCustId(),
                command.getName(),
                command.getDob(),
                command.getEmail(),
                command.getMobileNumber(),
                command.getAddress(),
                command.getCreationDate());
    	customerRepository.add(customer);
    }

    @CommandHandler
    public void handle(UpdateCustomerNameCommand command) {
    	System.out.println("in handler   ======");
    	CustomerAggregate customer = customerRepository.load(command.getCorrelatedId());
    	System.out.println("in handler  "+customer.getIdentifier() + " "+command.getCustId());
    	//customer.updateCustomerName(customer.getIdentifier(), command.getCustId(),command.getName(), command.getCreationDate());
    }
	
	
	
    @Autowired
    public void setRepository(EventSourcingRepository<CustomerAggregate> customerRepository) {
        this.customerRepository = customerRepository;
    }

	
*/	
/*
	private Repository repository;

    @Autowired
    public CreateCustomerHandler(Repository repository) {
        this.repository = repository;
    }
    //@Autowired
	//CustomerAggregate customerAggrgate;
    @CommandHandler
    public void handle(CreateCustomerCommand createCustomerCommandCommand){
        new CustomerCreatedEvent(createCustomerCommandCommand.getCorrelatedId(), createCustomerCommandCommand);

      //  CustomerAggregate customerAggrgate = (CustomerAggregate) repository.load(createCustomerCommandCommand.getCustId());
    	
    	//CustomerAggregate.createCustomer(createCustomerCommandCommand);
       // accountToCredit.credit(creditAccountCommandCommand.getAmount());
    }
*/
}
