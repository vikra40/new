package com.commandHandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.command.CreateCustomerCommand;
import com.domain.CustomerAggregate;
import com.event.CustomerCreatedEvent;

@Component
public class CreateCustomerHandler {

	/*private Repository repository;

    @Autowired
    public CreateCustomerHandler(Repository repository) {
        this.repository = repository;
    }
*/    //@Autowired
	//CustomerAggregate customerAggrgate;
    @CommandHandler
    public void handle(CreateCustomerCommand createCustomerCommandCommand){
        new CustomerCreatedEvent(createCustomerCommandCommand.getCorrelatedId(), createCustomerCommandCommand);

      //  CustomerAggregate customerAggrgate = (CustomerAggregate) repository.load(createCustomerCommandCommand.getCustId());
    	
    	//CustomerAggregate.createCustomer(createCustomerCommandCommand);
       // accountToCredit.credit(creditAccountCommandCommand.getAmount());
    }

}
