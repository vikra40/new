package com.commandHandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.command.CreateCustomerCommand;
import com.domain.CustomerAggregate;

@Component
public class CreateCustomerHandler {

	/*private Repository repository;

    @Autowired
    public CreateCustomerHandler(Repository repository) {
        this.repository = repository;
    }
*/    //@Autowired
	//CustomerAggregate customerAggrgate;
    @CommandHandler
    public void handle(CreateCustomerCommand createCustomerCommandCommand){
    	
      //  CustomerAggregate customerAggrgate = (CustomerAggregate) repository.load(createCustomerCommandCommand.getCustId());
    	
    	//CustomerAggregate.createCustomer(createCustomerCommandCommand);
       // accountToCredit.credit(creditAccountCommandCommand.getAmount());
    }

}
