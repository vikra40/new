package com.model;

public class Customer {

	private String custId;
	private String name;
	private String dob;
	private String email;
	private String mobileNumber;
	Address address;
	public Customer() {
		this.custId = custId;
		this.name = name;
		this.dob = dob;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.address = address;
	}
	public String getCustId() {
		return custId;
	}
	public String getName() {
		return name;
	}
	public String getDob() {
		return dob;
	}
	public String getEmail() {
		return email;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public Address getAddress() {
		return address;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	

}
