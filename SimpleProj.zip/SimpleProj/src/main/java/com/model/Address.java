package com.model;

public class Address {

	private String city;
	private String postalCode;
	private String country;
	public Address(){}
	public Address(String city, String postalCode, String country) {
		this.city = city;
		this.postalCode = postalCode;
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	

}
