package com.main;

import org.axonframework.eventsourcing.EventSourcingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.domain.CustomerAggregate;
import com.entry.CustomerEntryRepository;

@SpringBootApplication
@ComponentScan("com")
public class MainClass {
	

	/*
	@Autowired
	private CustomerRepository repository;

	public void run(String... args) throws Exception {}
	
*/
    public static void main(String[] args) {
    
        SpringApplication.run(MainClass.class, args);
        
        
    }
    

    
}
