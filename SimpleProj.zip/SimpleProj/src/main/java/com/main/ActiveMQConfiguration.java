package com.main;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
//import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.MessageListenerContainer;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageType;

import ch.qos.logback.classic.pattern.MessageConverter;

//import org.apache.activemq.ActiveMQConnectionFactory;

@SuppressWarnings("unused")
@Configuration
@EnableJms

public class ActiveMQConfiguration {
	
    //public static final String HELLO_QUEUE = "hello.queue";


    

    @Value("${spring.activemq.broker-url}")
    private String hostname;

    @Value("${spring.activemq.user}")
    private String username;

    @Value("${spring.activemq.password}")
    private String password;
/*
    @Value("${spring.application.exchange}")
    private String exchangeName;*/

    @Value("${spring.activemq.queue.name}")
    private String queueName;

    @Bean
    public ActiveMQQueue helloJMSQueue() {
        return new ActiveMQQueue(queueName);
    }
    
    
	@Bean
	public ActiveMQConnectionFactory connectionFactory(){
	    ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
	    connectionFactory.setBrokerURL(hostname);
	    connectionFactory.setPassword(username);
	    connectionFactory.setUserName(password);
	    return connectionFactory;
	}
    
     
 
    @Bean
    public ConnectionFactory cachingConnectionFactory(){
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setTargetConnectionFactory(connectionFactory());
        connectionFactory.setSessionCacheSize(10);
        return connectionFactory;
    }
	@Bean
	public JmsTemplate jmsTemplate(){
	    JmsTemplate template = new JmsTemplate();
	    template.setConnectionFactory(connectionFactory());
	    return template;
	}
	@Bean
    public MessageListenerContainer getContainer(){
        DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
        container.setConnectionFactory(connectionFactory());
        container.setDestinationName(queueName);
       // container.setMessageListener(messageReceiver);
        return container;
    } 
   /* @Bean
    SimpleMessageConverter converter(){
        return new SimpleMessageConverter();
    }
   */ 
    @Bean // Serialize message content to json using TextMessage
    public MappingJackson2MessageConverter jacksonJmsMessageConverter() {
        MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
        converter.setTargetType(MessageType.TEXT);
        converter.setTypeIdPropertyName("_type");
        return converter;
    }


}

