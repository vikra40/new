package com.main;

import javax.jms.JMSException;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MessageReceiver {

   /*
    @JmsListener(destination = "myCustomerQueue")
    public void receiveMessage() throws JMSException {
        System.out.println("in receiver ");
       
    }*/
}
