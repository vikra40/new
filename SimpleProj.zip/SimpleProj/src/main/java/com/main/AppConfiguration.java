package com.main;

import java.io.File;
import java.util.Arrays;

import javax.jms.ConnectionFactory;
import javax.sql.DataSource;

import org.axonframework.commandhandling.CommandBus;
import org.axonframework.commandhandling.SimpleCommandBus;
import org.axonframework.commandhandling.annotation.AggregateAnnotationCommandHandler;
import org.axonframework.commandhandling.annotation.AnnotationCommandHandlerBeanPostProcessor;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.commandhandling.gateway.CommandGatewayFactoryBean;
import org.axonframework.commandhandling.interceptors.BeanValidationInterceptor;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.SimpleEventBus;
import org.axonframework.eventhandling.annotation.AnnotationEventListenerBeanPostProcessor;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.axonframework.eventstore.EventStore;
import org.axonframework.eventstore.fs.FileSystemEventStore;
import org.axonframework.eventstore.fs.SimpleEventFileResolver;
import org.axonframework.eventstore.jdbc.JdbcEventStore;
import org.axonframework.eventstore.mongo.DefaultMongoTemplate;
import org.axonframework.eventstore.mongo.MongoEventStore;
import org.axonframework.serializer.json.JacksonSerializer;
//import org.axonframework.eventstore.mongo.DefaultMongoTemplate;
import org.h2.server.web.WebServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.jms.annotation.EnableJms;

import com.domain.CustomerAggregate;
import com.mongodb.Mongo;





/**
 * Created by Dadepo Aderemi.
 */
@Configuration
@EnableJms
@EnableMongoRepositories("com.entry")
public class AppConfiguration {

    @Autowired
    public ConnectionFactory connectionFactory;




    
    @Value("${spring.activemq.queue.name}")
    private String queueName;



    
/*
    @Bean
    ListenerContainerLifecycleManager listenerContainerLifecycleManager() {
        ListenerContainerLifecycleManager mgr = new ListenerContainerLifecycleManager();
        mgr.setConnectionFactory(connectionFactory);
        return mgr;
    }*/

/*    @Bean
    SpringAMQPConsumerConfiguration springAMQPConsumerConfiguration() {
        SpringAMQPConsumerConfiguration cfg = new SpringAMQPConsumerConfiguration();
        cfg.setTransactionManager(transactionManager);
        cfg.setQueueName(queueName);
        cfg.setTxSize(10);
        return cfg;
    }
*/


	
	
	
	
	
	
	
	
	
	
	
	@Autowired
    public Mongo mongo;

    @Value("${spring.data.mongodb.database}")
    private String databaseName;

    @Value("${spring.data.mongodb.collectionName}")
    private String eventsCollectionName;

    @Value("${spring.data.mongodb.snapshotName}")
    private String snapshotCollectionName;

	
	 @Bean  
	 public DataSource dataSource() {  
	      return DataSourceBuilder  
	                .create()  
	                .username("sa")  
	                .password("")  
	                .url("jdbc:h2:mem:axonappdb")  
	                .driverClassName("org.h2.Driver")  
	                .build();  
	 }  
	  
	 /** 
	 * Event store to store events 
	 */  
	 @Bean  
	 public EventStore jdbcEventStore() {  
	      return new JdbcEventStore(dataSource());  
	 }  

	 @Bean
	 public ServletRegistrationBean h2servletRegistration() {
	     ServletRegistrationBean registration = new ServletRegistrationBean(new WebServlet());
	     registration.addUrlMappings("/console/*");
	     return registration;
	 }
	 
	@Bean
	public AnnotationEventListenerBeanPostProcessor annotationEventListenerBeanPostProcessor() {
		AnnotationEventListenerBeanPostProcessor processor = new AnnotationEventListenerBeanPostProcessor();
		processor.setEventBus(eventBus());
		return processor;
	}
	
	@Bean
	public AnnotationCommandHandlerBeanPostProcessor annotationCommandHandlerBeanPostProcessor() {
		AnnotationCommandHandlerBeanPostProcessor processor = new AnnotationCommandHandlerBeanPostProcessor();
		processor.setCommandBus(commandBus());
		return processor;
	}

	@Bean
	public CommandBus commandBus() {
		SimpleCommandBus commandBus = new SimpleCommandBus();
		commandBus.setHandlerInterceptors(Arrays.asList(new BeanValidationInterceptor()));
		return commandBus;
	}

	@Bean
	public EventBus eventBus() {
		return new SimpleEventBus();
	}
	
	@Bean
	public CommandGatewayFactoryBean<CommandGateway> commandGatewayFactoryBean() {
		CommandGatewayFactoryBean<CommandGateway> factory = new CommandGatewayFactoryBean<CommandGateway>();
		factory.setCommandBus(commandBus());
		return factory;
	}
    @Bean
    JacksonSerializer axonJsonSerializer() {
        return new JacksonSerializer();
    }

	 @Bean(name = "axonMongoTemplate")
	    DefaultMongoTemplate axonMongoTemplate() {
	        DefaultMongoTemplate template = new DefaultMongoTemplate(mongo, databaseName, eventsCollectionName, snapshotCollectionName);//DefaultMongoTemplate(mongo,databaseName, eventsCollectionName, snapshotCollectionName);
		 //MongoTemplate template;
	        return template;
	    }

	    @Bean
	    EventStore eventStore() {
	        //MongoEventStore eventStore = new MongoEventStore(xmlSerializer(), axonMongoTemplate());
	        MongoEventStore eventStore = new MongoEventStore(axonJsonSerializer(), axonMongoTemplate());
	        return eventStore;
	    }

	    @Bean
	    EventSourcingRepository<CustomerAggregate> customerRepository() {
	        EventSourcingRepository<CustomerAggregate> repo = new EventSourcingRepository<CustomerAggregate>(CustomerAggregate.class, eventStore());
	        repo.setEventBus(eventBus());
	        return repo;
	    }

	/*@Bean
	public EventSourcingRepository<CustomerAggregate> customerRepository() {
		FileSystemEventStore eventStore = new FileSystemEventStore(new SimpleEventFileResolver(new File("E://data/eventstore")));
		EventSourcingRepository<CustomerAggregate> repository = new EventSourcingRepository<CustomerAggregate>(CustomerAggregate.class,eventStore);
		repository.setEventBus(eventBus());
		return repository;
	}*/
	
	@Bean
	public AggregateAnnotationCommandHandler<CustomerAggregate> taskCommandHandler() {
		AggregateAnnotationCommandHandler<CustomerAggregate> commandHandler = AggregateAnnotationCommandHandler.subscribe(CustomerAggregate.class, customerRepository(), commandBus());
		return commandHandler;
	}
	
	
	/*

    @Bean
    public DataSource dataSource() {
        return DataSourceBuilder
                .create()
                .username("sa")
                .password("")
                .url("jdbc:h2:mem:exploredb")
                .driverClassName("org.h2.Driver")
                .build();
    }

    *//**
     * An event sourcing implementation needs a place to store events. i.e. The event Store.
     * In our use case we will be storing our events in database, so we configure
     * the JdbcEventStore as our EventStore implementation
     *
     * It should be noted that Axon allows storing the events
     * in other persistent mechanism...jdbc, jpa, filesystem etc
     *
     * @return the {@link EventStore}
     *//*
    @Bean
    public EventStore jdbcEventStore() {
        return new JdbcEventStore(dataSource());
    }

    @Bean
    public SimpleCommandBus commandBus() {
        SimpleCommandBus simpleCommandBus = new SimpleCommandBus();
        return simpleCommandBus;
    }

    *//**
     *  A cluster which can be used to "cluster" together event handlers. This implementation is based on
     * {@link SimpleCluster} and it would be used to cluster event handlers that would listen to events thrown
     * normally within the application.
     *
     * @return an instance of {@link SimpleCluster}
     *//*
    @Bean
    public Cluster normalCluster() {
        SimpleCluster simpleCluster = new SimpleCluster("simpleCluster");
        return simpleCluster;
    }

    *//**
     *  A cluster which can be used to "cluster" together event handlers. This implementation is based on
     * {@link SimpleCluster} and it would be used to cluster event handlers that would listen to replayed events.
     *
     * As can be seen, the bean is just a simple implementation of {@link SimpleCluster} there is nothing about
     * it that says it would be able to handle replayed events. The bean definition #replayCluster is what makes
     * this bean able to handle replayed events.
     *
     * @return an instance of {@link SimpleCluster}
     *//*
    @Bean
    public Cluster replay() {
        SimpleCluster simpleCluster = new SimpleCluster("replayCluster");
        return simpleCluster;
    }

    *//**
     * Takes the #replay() cluster and wraps it with a Replaying Cluser, turning the event handlers that are registered
     * to be able to pick up events when events are replayed.
     *
     * @return an instance of {@link ReplayingCluster}
     *//*
    @Bean
    public ReplayingCluster replayCluster() {
        IncomingMessageHandler incomingMessageHandler = new DiscardingIncomingMessageHandler();
        EventStoreManagement eventStore = (EventStoreManagement) jdbcEventStore();
        return new ReplayingCluster(replay(), eventStore, new NoTransactionManager(),0,incomingMessageHandler);
    }

    *//**
     * This configuration registers event handlers with the two defined clusters
     *
     * @return an instance of {@link ClusterSelector}
     *//*
    @Bean
    public ClusterSelector clusterSelector() {
        Map<String, Cluster> clusterMap = new HashMap<>();
        clusterMap.put("exploringaxon.eventhandler", normalCluster());
        clusterMap.put("exploringaxon.replay", replayCluster());
        return new ClassNamePrefixClusterSelector(clusterMap);
    }


    *//**
     * This replaces the simple event bus that was initially used. The clustering event bus is needed to be able
     * to route events to event handlers in the clusters. It is configured with a {@link EventBusTerminal} defined
     * by #terminal(). The EventBusTerminal contains the configuration rules which determines which cluster gets an
     * incoming event
     *
     * @return a {@link ClusteringEventBus} implementation of {@link EventBus}
     *//*
    @Bean
    public EventBus clusteringEventBus() {
        ClusteringEventBus clusteringEventBus = new ClusteringEventBus(clusterSelector(), terminal());
        return clusteringEventBus;
    }

    *//**
     * An {@link EventBusTerminal} which publishes application domain events onto the normal cluster
     *
     * @return an instance of {@link EventBusTerminal}
     *//*
    @Bean
    public EventBusTerminal terminal() {
        return new EventBusTerminal() {
            @Override
            public void publish(EventMessage... events) {
                normalCluster().publish(events);
            }
            @Override
            public void onClusterCreated(Cluster cluster) {

            }
        };
    }

    @Bean
    public DefaultCommandGateway commandGateway() {
        return new DefaultCommandGateway(commandBus());
    }

@Bean
public EventBus createEventBus() {
	EventBus eventBus = new SimpleEventBus();
   // ClusteringEventBus clusteringEventBus = new ClusteringEventBus(clusterSelector(), terminal());
    return eventBus;
}

@Bean
public AnnotationEventListenerBeanPostProcessor annotationEventListenerBeanPostProcessor() {

AnnotationEventListenerBeanPostProcessor listener = new AnnotationEventListenerBeanPostProcessor();
listener.setEventBus(createEventBus());
return listener;
}
    *//**
     * Our aggregate root is now created from stream of events and not from a representation in a persistent mechanism,
     * thus we need a repository that can handle the retrieving of our aggregate root from the stream of events.
     *
     * We configure the EventSourcingRepository which does exactly this. We supply it with the event store
     * @return a {@link EventSourcingRepository} implementation of {@link Repository}
     *//*
    @Bean
    public Repository<CustomerAggregate> eventSourcingRepository() {
        EventSourcingRepository eventSourcingRepository = new EventSourcingRepository(CustomerAggregate.class, jdbcEventStore());
        eventSourcingRepository.setEventBus(createEventBus());
        return eventSourcingRepository;
    }
   
    


    @Bean
    AnnotationCommandHandlerBeanPostProcessor annotationCommandHandlerBeanPostProcessor() {
    	AnnotationCommandHandlerBeanPostProcessor p =  new AnnotationCommandHandlerBeanPostProcessor();
        p.setCommandBus(commandBus());
        return p;
    }

@Bean
AnnotationEventListenerBeanPostProcessor annotationEventListenerBeanPostProcessor() {
	AnnotationEventListenerBeanPostProcessor p = new AnnotationEventListenerBeanPostProcessor();
        p.setEventBus(createEventBus());
        return p;
    }
@Bean
public Repository<CustomerAggregate> customerRepository() {
	
	FileSystemEventStore eventStore = new FileSystemEventStore(new SimpleEventFileResolver(new File("data/evenstore")));
	EventSourcingRepository<CustomerAggregate> repository = new EventSourcingRepository<CustomerAggregate>(CustomerAggregate.class, eventStore);
	repository.setEventBus(createEventBus());
	return repository;

	
     EventStore eventStore = new FileSystemEventStore(new SimpleEventFileResolver(new File("D://sevents.txt")));
    EventSourcingRepository eventSourcingRepository = new EventSourcingRepository(CustomerAggregate.class, eventStore);
    eventSourcingRepository.setEventBus(createEventBus());
    AnnotationEventListenerAdapter.subscribe(new CustomerCreatedEventHandler(), createEventBus());
    return eventSourcingRepository;
}
@Bean
public AggregateAnnotationCommandHandler<CustomerAggregate> taskCommandHandler() {
	AggregateAnnotationCommandHandler<CustomerAggregate> commandHandler = AggregateAnnotationCommandHandler.subscribe(CustomerAggregate.class, customerRepository(), commandBus());
	return commandHandler;
}
*/
}
